const mongoose = require('mongoose');
const User = require('../models/User');
require('dotenv').config();

const createDemoUsers = async () => {
  await mongoose.connect(process.env.MONGODB_URI);
  
  const demoUsers = [
    {
      username: 'demoreader',
      email: 'demo@storyverse.com',
      password: 'demo123',
      role: 'user'
    },
    {
      username: 'admin',
      email: 'admin@storyverse.com',
      password: 'admin123',
      role: 'admin'
    },
    {
      username: 'Peter',
      email: 'moneybagg@gmail.com',
      password: '0278808$Bu',
      role: 'admin'
    }
  ];

  for (const userData of demoUsers) {
    const user = new User(userData);
    await user.save();
    console.log(`Created ${user.role} user: ${user.email}`);
  }

  mongoose.connection.close();
};

createDemoUsers().catch(console.error);