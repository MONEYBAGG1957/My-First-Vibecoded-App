import React from "react";
import {
  Home,
  Search,
  Library,
  Heart,
  Settings,
  LogOut,
  BookOpen,
  User,
  // Plus,
  // FileText,
  BarChart3,
  Tag,
} from "lucide-react";
import { useApp } from "../../context/AppContext";

interface SidebarProps {
  currentView: string;
  onViewChange: (view: string) => void;
  onLogout: () => void;
  isOpen?: boolean;
  onClose?: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onViewChange,
  onLogout,
  isOpen = false,
}) => {
  const { state, isAdmin } = useApp();

  const userNavItems = [
    { id: "home", label: "Discover", icon: Home },
    { id: "search", label: "Search", icon: Search },
    { id: "library", label: "My Library", icon: Library },
    { id: "favorites", label: "Favorites", icon: Heart },
    { id: "profile", label: "Profile", icon: User },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const adminNavItems = [
    { id: "dashboard", label: "Dashboard", icon: BarChart3 },
    // { id: "add-story", label: "Add Story", icon: Plus },
    { id: "manage-stories", label: "Manage Stories", icon: BookOpen },
    // { id: "drafts", label: "Drafts", icon: FileText },
    { id: "categories", label: "Categories", icon: Tag },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const navItems = isAdmin ? adminNavItems : userNavItems;

  return (
    <div
      className={`
      w-64 bg-[var(--bg-secondary)] border-r border-[var(--border-color)] h-screen flex flex-col shadow-sm
      fixed lg:relative z-50 lg:z-auto
      transform transition-transform duration-300 ease-in-out
      ${isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
    `}
    >
      {/* Mobile Close Button */}
      {/* <div className="lg:hidden p-4 border-b border-[var(--border-color)] flex justify-end">
        <button
          onClick={onClose}
          className="p-2 text-[var(--neutral-600)] hover:text-[var(--primary)] transition-colors duration-200"
        >
          <X className="w-5 h-5" />
        </button>
      </div> */}

      <div className="p-6 border-b border-[var(--border-color)]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[var(--primary)] rounded-lg flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-xl text-[var(--primary)] font-['Playfair_Display']">
              StoryVerse
            </h1>
            {state.user && (
              <p className="text-sm text-[var(--neutral-500)] capitalize">
                {state.user.role} Portal
              </p>
            )}
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 overflow-y-auto">
        <ul className="space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onViewChange(item.id)}
                  className={`sidebar-link w-full text-left ${
                    currentView === item.id ? "active" : ""
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      {state.user && (
        <div className="p-4 border-t border-[var(--border-color)] pb-[env(safe-area-inset-bottom)]">
          <div className="flex items-center gap-3 mb-4 p-3 bg-[var(--neutral-50)] rounded-lg">
            <div className="w-10 h-10 bg-[var(--secondary)] rounded-full flex items-center justify-center">
              <User className="w-5 h-5 text-[var(--primary)]" />
            </div>
            <div>
              <p className="font-medium text-sm text-[var(--neutral-800)]">
                {state.user.name}
              </p>
              <p className="text-xs text-[var(--neutral-500)]">
                {state.user.email}
              </p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="sidebar-link w-full text-left text-[var(--error)] hover:bg-red-50 hover:text-[var(--error)]"
          >
            <LogOut className="w-5 h-5" />
            <span className="font-medium">Logout</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
