import React, { useState } from "react";
import {
  User,
  Edit2,
  Save,
  X,
  Calendar,
  Shield,
  BookOpen,
  Heart,
  Clock,
} from "lucide-react";
import { useApp } from "../../context/AppContext";

const ProfilePage: React.FC = () => {
  const { state, login } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: state.user?.name || "",
    email: state.user?.email || "",
  });

  const handleSave = () => {
    if (state.user) {
      const updatedUser = {
        ...state.user,
        name: editForm.name,
        email: editForm.email,
      };
      login(updatedUser);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditForm({
      name: state.user?.name || "",
      email: state.user?.email || "",
    });
    setIsEditing(false);
  };

  if (!state.user) {
    return (
      <div className="flex-1 bg-[var(--neutral-50)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-[var(--neutral-600)] mb-4">
            Please log in to view your profile
          </h2>
        </div>
      </div>
    );
  }

  // Calculate reading stats
  const totalStoriesRead = state.readingProgress.length;
  const completedStories = state.readingProgress.filter(
    (p) => p.progress_percent >= 100
  ).length;
  const favoriteCount = state.favorites.length;
  const averageProgress =
    totalStoriesRead > 0
      ? Math.round(
          state.readingProgress.reduce(
            (sum, p) => sum + p.progress_percent,
            0
          ) / totalStoriesRead
        )
      : 0;

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-2">
            My Profile
          </h1>
          <p className="text-base sm:text-lg text-[var(--neutral-600)]">
            Manage your account and view your reading statistics
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
          {/* Profile Information */}
          <div className="lg:col-span-2">
            <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-6 sm:p-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-semibold text-[var(--neutral-800)] font-['Playfair_Display']">
                  Profile Information
                </h2>
                {!isEditing ? (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="flex items-center gap-2 text-[var(--primary)] hover:text-[var(--primary)]/80 transition-colors duration-200"
                  >
                    <Edit2 className="w-4 h-4" />
                    <span>Edit</span>
                  </button>
                ) : (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSave}
                      className="flex items-center gap-2 text-[var(--secondary)] hover:text-[var(--secondary)]/80 transition-colors duration-200"
                    >
                      <Save className="w-4 h-4" />
                      <span>Save</span>
                    </button>
                    <button
                      onClick={handleCancel}
                      className="flex items-center gap-2 text-[var(--neutral-500)] hover:text-[var(--neutral-700)] transition-colors duration-200"
                    >
                      <X className="w-4 h-4" />
                      <span>Cancel</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="flex items-start gap-6 mb-8">
                <div className="w-20 h-20 bg-[var(--primary)] rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-10 h-10 text-white" />
                </div>
                <div className="flex-1">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                        Full Name
                      </label>
                      {isEditing ? (
                        <input
                          type="text"
                          value={editForm.name}
                          onChange={(e) =>
                            setEditForm({ ...editForm, name: e.target.value })
                          }
                          className="input-field"
                          placeholder="Enter your full name"
                        />
                      ) : (
                        <p className="text-[var(--neutral-800)] font-medium">
                          {state.user.name}
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                        Email Address
                      </label>
                      {isEditing ? (
                        <input
                          type="email"
                          value={editForm.email}
                          onChange={(e) =>
                            setEditForm({ ...editForm, email: e.target.value })
                          }
                          className="input-field"
                          placeholder="Enter your email address"
                        />
                      ) : (
                        <p className="text-[var(--neutral-800)]">
                          {state.user.email}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Account Details */}
              <div className="border-t border-[var(--neutral-200)] pt-6">
                <h3 className="text-lg font-medium text-[var(--neutral-800)] mb-4">
                  Account Details
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex items-center gap-3 p-3 bg-[var(--neutral-50)] rounded-lg">
                    <Shield className="w-5 h-5 text-[var(--primary)]" />
                    <div>
                      <p className="text-sm font-medium text-[var(--neutral-800)] capitalize">
                        {state.user.role}
                      </p>
                      <p className="text-xs text-[var(--neutral-500)]">
                        Account Type
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-[var(--neutral-50)] rounded-lg">
                    <Calendar className="w-5 h-5 text-[var(--secondary)]" />
                    <div>
                      <p className="text-sm font-medium text-[var(--neutral-800)]">
                        {new Date(state.user.created_at).toLocaleDateString()}
                      </p>
                      <p className="text-xs text-[var(--neutral-500)]">
                        Member Since
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Reading Statistics */}
          <div className="space-y-6">
            <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-6">
              <h3 className="text-lg font-semibold text-[var(--neutral-800)] font-['Playfair_Display'] mb-4">
                Reading Statistics
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-[var(--neutral-50)] rounded-lg">
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-5 h-5 text-[var(--primary)]" />
                    <span className="text-sm font-medium text-[var(--neutral-700)]">
                      Stories Started
                    </span>
                  </div>
                  <span className="text-lg font-bold text-[var(--neutral-800)]">
                    {totalStoriesRead}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-[var(--neutral-50)] rounded-lg">
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-[var(--secondary)]" />
                    <span className="text-sm font-medium text-[var(--neutral-700)]">
                      Completed
                    </span>
                  </div>
                  <span className="text-lg font-bold text-[var(--neutral-800)]">
                    {completedStories}
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 bg-[var(--neutral-50)] rounded-lg">
                  <div className="flex items-center gap-3">
                    <Heart className="w-5 h-5 text-[var(--error)]" />
                    <span className="text-sm font-medium text-[var(--neutral-700)]">
                      Favorites
                    </span>
                  </div>
                  <span className="text-lg font-bold text-[var(--neutral-800)]">
                    {favoriteCount}
                  </span>
                </div>

                {totalStoriesRead > 0 && (
                  <div className="p-3 bg-[var(--neutral-50)] rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-[var(--neutral-700)]">
                        Average Progress
                      </span>
                      <span className="text-lg font-bold text-[var(--neutral-800)]">
                        {averageProgress}%
                      </span>
                    </div>
                    <div className="w-full bg-[var(--neutral-200)] rounded-full h-2">
                      <div
                        className="progress-bar h-2 rounded-full transition-all duration-300"
                        style={{ width: `${averageProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-6">
              <h3 className="text-lg font-semibold text-[var(--neutral-800)] font-['Playfair_Display'] mb-4">
                Recent Activity
              </h3>
              {state.readingProgress.length > 0 ? (
                <div className="space-y-3">
                  {state.readingProgress
                    .sort(
                      (a, b) =>
                        new Date(b.last_read).getTime() -
                        new Date(a.last_read).getTime()
                    )
                    .slice(0, 3)
                    .map((progress) => {
                      const story = state.stories.find(
                        (s) => s.id === progress.story_id
                      );
                      return story ? (
                        <div
                          key={progress.id}
                          className="flex items-center gap-3 p-2"
                        >
                          <div className="w-8 h-8 bg-[var(--primary)]/10 rounded-full flex items-center justify-center">
                            <BookOpen className="w-4 h-4 text-[var(--primary)]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-[var(--neutral-800)] truncate">
                              {story.title}
                            </p>
                            <p className="text-xs text-[var(--neutral-500)]">
                              {Math.round(progress.progress_percent)}% complete
                            </p>
                          </div>
                        </div>
                      ) : null;
                    })}
                </div>
              ) : (
                <p className="text-sm text-[var(--neutral-500)]">
                  No reading activity yet. Start reading to see your progress
                  here!
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
