const express = require('express');
const {
  getPublishedStories,
  getStory,
  createStory,
  updateStory,
  deleteStory,
  getUserStories,
  getChapter,
  getStoryChapters
} = require('../controllers/storyController');
const { protect } = require('../middleware/authMiddleware');

const router = express.Router();
// Add these routes
router.get('/:storyId/chapters', getStoryChapters);
router.get('/:storyId/chapters/:chapterId', getChapter);

// Public routes
router.get('/', getPublishedStories);
router.get('/:id', getStory);

// Protected routes (require authentication)
router.use(protect);

// Admin/author routes
router.post('/', createStory);
router.get('/user/my-stories', getUserStories);
router.put('/:id', updateStory);
router.delete('/:id', deleteStory);

module.exports = router;