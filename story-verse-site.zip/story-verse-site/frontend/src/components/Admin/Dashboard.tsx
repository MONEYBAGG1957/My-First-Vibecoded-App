import React from "react";
import {
  BookOpen,
  FileText,
  // Users,
  Eye,
  TrendingUp,
  Clock,
} from "lucide-react";
import { useApp } from "../../context/AppContext";

interface DashboardProps {
  onNavigate?: (view: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const { state } = useApp();

  const publishedStories = state.stories.filter(
    (story) => story.status === "published"
  );
  const draftStories = state.stories.filter(
    (story) => story.status === "draft"
  );
  const totalReads = state.readingProgress.length;

  const stats = [
    {
      title: "Total Stories",
      value: state.stories.length,
      icon: BookOpen,
      color: "text-[var(--primary)]",
      bg: "bg-[var(--primary)]/10",
    },
    {
      title: "Published",
      value: publishedStories.length,
      icon: Eye,
      color: "text-[var(--secondary)]",
      bg: "bg-[var(--secondary)]/10",
    },
    {
      title: "Drafts",
      value: draftStories.length,
      icon: FileText,
      color: "text-[var(--tertiary)]",
      bg: "bg-[var(--tertiary)]/10",
    },
    {
      title: "Total Reads",
      value: totalReads,
      icon: TrendingUp,
      color: "text-[var(--quaternary)]",
      bg: "bg-[var(--quaternary)]/10",
    },
  ];

  const recentStories = state.stories
    .sort(
      (a, b) =>
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
    )
    .slice(0, 5);

  return (
    <div className="flex-1 bg-[var(--bg-primary)] overflow-y-auto">
      <div className="p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-[var(--text-primary)] font-['Playfair_Display'] mb-2">
            Admin Dashboard
          </h1>
          <p className="text-lg text-[var(--text-secondary)]">
            Manage your stories and track platform performance
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat) => {
            const Icon = stat.icon;
            return (
              <div
                key={stat.title}
                className="bg-[var(--bg-secondary)] rounded-xl shadow-sm border border-[var(--border-color)] p-6 hover:shadow-md transition-shadow duration-200"
              >
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-12 h-12 ${stat.bg} rounded-lg flex items-center justify-center`}
                  >
                    <Icon className={`w-6 h-6 ${stat.color}`} />
                  </div>
                </div>
                <h3 className="text-2xl font-bold text-[var(--text-primary)] mb-1">
                  {stat.value}
                </h3>
                <p className="text-[var(--text-secondary)] font-medium">
                  {stat.title}
                </p>
              </div>
            );
          })}
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Stories */}
          <div className="bg-[var(--bg-secondary)] rounded-xl shadow-sm border border-[var(--border-color)]">
            <div className="p-6 border-b border-[var(--border-color)]">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[var(--primary)]" />
                <h3 className="text-xl font-semibold text-[var(--text-primary)] font-['Playfair_Display']">
                  Recent Stories
                </h3>
              </div>
            </div>
            <div className="divide-y divide-[var(--border-color)]">
              {recentStories.map((story) => (
                <div
                  key={story.id}
                  className="p-6 hover:bg-[var(--neutral-100)] transition-colors duration-200"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={
                        story.cover_url ||
                        "https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=100"
                      }
                      alt={story.title}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-[var(--text-primary)] mb-1 truncate">
                        {story.title}
                      </h4>
                      <p className="text-sm text-[var(--text-secondary)] mb-2 line-clamp-2">
                        {story.description}
                      </p>
                      <div className="flex items-center gap-3">
                        <span
                          className={`px-2 py-1 text-xs rounded-full ${
                            story.status === "published"
                              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                              : "bg-[var(--tertiary)] text-white"
                          }`}
                        >
                          {story.status}
                        </span>
                        <span className="text-xs text-[var(--text-secondary)]">
                          {new Date(story.updated_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-[var(--bg-secondary)] rounded-xl shadow-sm border border-[var(--border-color)]">
            <div className="p-6 border-b border-[var(--border-color)]">
              <h3 className="text-xl font-semibold text-[var(--text-primary)] font-['Playfair_Display']">
                Quick Actions
              </h3>
            </div>
            <div className="p-6 space-y-4">
              {/* <button
                onClick={() => onNavigate?.("add-story")}
                className="btn-primary w-full flex items-center justify-center gap-3"
              >
                <BookOpen className="w-5 h-5" />
                Create New Story
              </button> */}
              {/* <button
                onClick={() => onNavigate?.("drafts")}
                className="btn-secondary w-full flex items-center justify-center gap-3"
              >
                <FileText className="w-5 h-5" />
                View All Drafts
              </button> */}
              <button
                onClick={() => onNavigate?.("manage-stories")}
                className="btn-secondary w-full flex items-center justify-center gap-3"
              >
                <BookOpen className="w-5 h-5" />
                Manage Stories
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
