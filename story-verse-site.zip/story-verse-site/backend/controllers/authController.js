const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Debug the User model import
console.log('🔍 User model imported:', typeof User);
console.log('🔍 User model properties:', User && Object.keys(User));
console.log('🔍 Is User a function?', typeof User === 'function');
console.log('🔍 Does User have findOne?', User && typeof User.findOne === 'function');

const signToken = (id, role) => {
  return jwt.sign(
    { id, role }, 
    process.env.JWT_SECRET || 'your-secret-key',
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
};

exports.login = async (req, res) => {
  try {
    console.log('🔐 Login attempt:', req.body);
    
    const { email, password } = req.body;

    // 1) Check if email and password exist
    if (!email || !password) {
      return res.status(400).json({
        status: 'error',
        message: 'Please provide email and password'
      });
    }

    // 2) Find user with password field
    const user = await User.findOne({ email }).select('+password');
    console.log('🔍 User found:', user ? {
      id: user._id,
      email: user.email,
      hasPassword: !!user.password
    } : 'No user found');
    
    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'Incorrect email or password'
      });
    }

    // 3) Debug user methods
    console.log('🔑 User methods:', Object.keys(user));
    console.log('🔑 correctPassword method exists:', typeof user.correctPassword === 'function');
    
    if (typeof user.correctPassword !== 'function') {
      return res.status(500).json({
        status: 'error',
        message: 'Authentication method not available'
      });
    }

    // 4) Check password
    const isPasswordCorrect = await user.correctPassword(password, user.password);
    console.log('🔑 Password correct:', isPasswordCorrect);
    
    if (!isPasswordCorrect) {
      return res.status(401).json({
        status: 'error',
        message: 'Incorrect email or password'
      });
    }

    // 5) Generate token
    const token = signToken(user._id, user.role);
    console.log('🔑 Token generated successfully');

    // 6) Send response
    res.status(200).json({
      status: 'success',
      token,
      data: {
        user: {
          id: user._id,
          email: user.email,
          username: user.username,
          role: user.role,
          created_at: user.createdAt
        }
      }
    });

  } catch (error) {
    console.error('💥 Login error details:');
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    
    res.status(500).json({
      status: 'error',
      message: 'Error logging in',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

exports.signup = async (req, res) => {
  try {
    console.log('📝 Signup attempt:', req.body);
    
    const { username, email, password, passwordConfirm } = req.body;

    // 1) Check required fields
    if (!username || !email || !password) {
      return res.status(400).json({
        status: 'error',
        message: 'Please provide username, email, and password'
      });
    }

    // 2) Check if passwords match (if passwordConfirm provided)
    if (passwordConfirm && password !== passwordConfirm) {
      return res.status(400).json({
        status: 'error',
        message: 'Passwords do not match'
      });
    }

    // 3) Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { username }]
    });
    console.log('🔍 Existing user check:', existingUser ? 'User exists' : 'No existing user');

    if (existingUser) {
      return res.status(400).json({
        status: 'error',
        message: 'User with this email or username already exists'
      });
    }

    // 4) Create new user
    console.log('✅ Creating new user...');
    const newUser = await User.create({
      username,
      email,
      password,
      role: 'user'
    });
    console.log('✅ User created successfully:', {
      id: newUser._id,
      email: newUser.email,
      username: newUser.username
    });

    // 5) Generate token
    const token = signToken(newUser._id, newUser.role);

    // 6) Remove password from output
    newUser.password = undefined;

    // 7) Send response
    res.status(201).json({
      status: 'success',
      token,
      data: {
        user: {
          id: newUser._id,
          username: newUser.username,
          email: newUser.email,
          role: newUser.role,
          created_at: newUser.createdAt
        }
      }
    });

  } catch (error) {
    console.error('💥 Signup error details:');
    console.error('Error name:', error.name);
    console.error('Error message:', error.message);
    console.error('Error code:', error.code);
    console.error('Error stack:', error.stack);
    
    // Handle specific error types
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        status: 'error',
        message: messages.join(', ')
      });
    }
    
    if (error.code === 11000) {
      return res.status(400).json({
        status: 'error',
        message: 'User with this email or username already exists'
      });
    }

    res.status(500).json({
      status: 'error',
      message: 'Error creating account',
      error: process.env.NODE_ENV === 'development' ? error.message : 'Internal server error'
    });
  }
};

exports.logout = (req, res) => {
  // In a real application, you might want to blacklist the token
  // For now, we'll just send a success response
  res.status(200).json({
    status: 'success',
    message: 'Logged out successfully'
  });
};

// Optional: Add token verification endpoint
exports.verifyToken = async (req, res) => {
  try {
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({
        status: 'error',
        message: 'No token provided'
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
    const user = await User.findById(decoded.id);

    if (!user) {
      return res.status(401).json({
        status: 'error',
        message: 'User no longer exists'
      });
    }

    res.status(200).json({
      status: 'success',
      data: {
        user: {
          id: user._id,
          username: user.username,
          email: user.email,
          role: user.role,
          created_at: user.createdAt
        }
      }
    });

  } catch (error) {
    res.status(401).json({
      status: 'error',
      message: 'Invalid token'
    });
  }
};