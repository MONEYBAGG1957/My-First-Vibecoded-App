import React, { useState } from "react";
import { Search, Sparkles, TrendingUp, Clock } from "lucide-react";
import { useApp } from "../../context/AppContext";
import StoryCard from "./StoryCard";

interface HomePageProps {
  onStorySelect: (storyId: string) => void;
}

const HomePage: React.FC<HomePageProps> = ({ onStorySelect }) => {
  const { state } = useApp();
  const [searchTerm, setSearchTerm] = useState("");

  const publishedStories = state.stories.filter(
    (story) => story.status === "published"
  );
  const storiesWithProgress = state.readingProgress
    .map((progress) =>
      publishedStories.find((story) => story.id === progress.story_id)
    )
    .filter(Boolean);

  const filteredStories = publishedStories.filter(
    (story) =>
      story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      story.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (story.author &&
        story.author.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-2">
            Discover Amazing Stories
          </h1>
          <p className="text-base sm:text-lg text-[var(--neutral-600)]">
            Immerse yourself in worlds of imagination and adventure
          </p>
        </div>

        {/* Search */}
        <div className="relative mb-6 sm:mb-8">
          <Search className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-4 h-4 sm:w-5 sm:h-5" />
          <input
            type="text"
            placeholder="Search stories, authors, or descriptions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 sm:pl-12 text-base sm:text-lg"
          />
        </div>

        {/* Continue Reading Section */}
        {storiesWithProgress.length > 0 && (
          <div className="mb-8 sm:mb-10">
            <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
              <Clock className="w-5 h-5 sm:w-6 sm:h-6 text-[var(--primary)]" />
              <h2 className="text-xl sm:text-2xl font-semibold text-[var(--neutral-800)] font-['Playfair_Display']">
                Continue Reading
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {storiesWithProgress
                .slice(0, 4)
                .map(
                  (story) =>
                    story && (
                      <StoryCard
                        key={story.id}
                        story={story}
                        onClick={() => onStorySelect(story.id)}
                        showProgress={true}
                      />
                    )
                )}
            </div>
          </div>
        )}

        {/* Featured Stories Section */}
        <div className="mb-8 sm:mb-10">
          <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
            <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-[var(--secondary)]" />
            <h2 className="text-xl sm:text-2xl font-semibold text-[var(--neutral-800)] font-['Playfair_Display']">
              Featured Stories
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {filteredStories.slice(0, 8).map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                onClick={() => onStorySelect(story.id)}
              />
            ))}
          </div>
        </div>

        {/* All Stories */}
        {filteredStories.length > 8 && (
          <div>
            <div className="flex items-center gap-2 sm:gap-3 mb-4 sm:mb-6">
              <TrendingUp className="w-5 h-5 sm:w-6 sm:h-6 text-[var(--tertiary)]" />
              <h2 className="text-xl sm:text-2xl font-semibold text-[var(--neutral-800)] font-['Playfair_Display']">
                All Stories
              </h2>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {filteredStories.slice(8).map((story) => (
                <StoryCard
                  key={story.id}
                  story={story}
                  onClick={() => onStorySelect(story.id)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Empty State */}
        {filteredStories.length === 0 && searchTerm && (
          <div className="text-center py-16">
            <Search className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
            <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
              No stories found
            </h3>
            <p className="text-[var(--neutral-500)]">
              Try adjusting your search terms or browse all available stories
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default HomePage;
