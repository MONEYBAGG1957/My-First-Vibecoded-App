import React, { useState } from "react";
import { BookOpen, Eye, EyeOff, User, Mail, Lock } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";
import { useApp } from "../../context/AppContext"; // Import useApp for auto-login

interface SignupFormProps {
  onSignupSuccess?: () => void;
  onNavigateToLogin?: () => void;
}

const SignupForm: React.FC<SignupFormProps> = ({
  onSignupSuccess,
  onNavigateToLogin,
}) => {
  const { theme } = useTheme();
  const { login } = useApp(); // Get login function from AppContext

  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    // Basic client-side validation
    if (formData.username.length < 3) {
      setMessage({
        type: "error",
        text: "Username must be at least 3 characters long.",
      });
      setLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setMessage({
        type: "error",
        text: "Password must be at least 6 characters long.",
      });
      setLoading(false);
      return;
    }

    try {
      // ✅ FIX: Use the correct backend URL with port 5000
      const response = await fetch("http://localhost:5000/api/auth/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        setMessage({
          type: "success",
          text: "Account created successfully! You are now logged in.",
        });

        // ✅ AUTO-LOGIN: Store token and log the user in automatically
        localStorage.setItem("token", data.token);
        login(data.data.user); // This will update the app state

        setFormData({ username: "", email: "", password: "" });

        // Call success callback after a short delay
        setTimeout(() => {
          onSignupSuccess?.();
        }, 1500);
      } else {
        setMessage({
          type: "error",
          text: data.message || "Failed to create account. Please try again.",
        });
      }
    } catch (error) {
      console.error("Signup failed:", error);
      setMessage({
        type: "error",
        text: "Network error. Please check your connection and try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (message) setMessage(null);
  };

  // ... rest of your JSX code remains the same

  return (
    <div
      className={`min-h-screen flex items-center justify-center p-4 ${
        theme === "light"
          ? "bg-gradient-to-br from-[var(--neutral-50)] to-[var(--neutral-100)]"
          : "bg-gradient-to-br from-neutral-950 to-neutral-900"
      }`}
    >
      <div className="max-w-md w-full">
        <div
          className={`rounded-2xl p-8 border shadow-xl ${
            theme === "light"
              ? "bg-white border-[var(--primary)] shadow-none"
              : "bg-neutral-900 border-[var(--primary)] shadow-[0_0_15px_var(--primary)]"
          }`}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-[var(--primary)] rounded-2xl flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-[var(--primary)] font-['Playfair_Display'] mb-2">
              Join StoryVerse
            </h1>
            <p
              className={`${
                theme === "light"
                  ? "text-[var(--neutral-600)]"
                  : "text-gray-300"
              }`}
            >
              Create your account and start your reading journey
            </p>
          </div>

          {/* Alerts */}
          {message && (
            <div
              className={`mb-6 p-4 rounded-lg ${
                message.type === "success"
                  ? "bg-green-50 text-green-800 border border-green-200"
                  : "bg-red-50 text-red-800 border border-red-200"
              }`}
            >
              {message.text}
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Username */}
            <div>
              <label
                className={`block text-sm font-medium mb-2 ${
                  theme === "light"
                    ? "text-[var(--neutral-700)]"
                    : "text-gray-200"
                }`}
              >
                Username
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-5 h-5" />
                <input
                  type="text"
                  required
                  className="input-field pl-12"
                  placeholder="Choose a username"
                  value={formData.username}
                  onChange={(e) =>
                    handleInputChange("username", e.target.value)
                  }
                  minLength={3}
                  maxLength={20}
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label
                className={`block text-sm font-medium mb-2 ${
                  theme === "light"
                    ? "text-[var(--neutral-700)]"
                    : "text-gray-200"
                }`}
              >
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-5 h-5" />
                <input
                  type="email"
                  required
                  className="input-field pl-12"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={(e) => handleInputChange("email", e.target.value)}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label
                className={`block text-sm font-medium mb-2 ${
                  theme === "light"
                    ? "text-[var(--neutral-700)]"
                    : "text-gray-200"
                }`}
              >
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-5 h-5" />
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  className="input-field pl-12 pr-12"
                  placeholder="Create a password"
                  value={formData.password}
                  onChange={(e) =>
                    handleInputChange("password", e.target.value)
                  }
                  minLength={6}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-500)] hover:text-[var(--primary)]"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              <p className="text-xs text-[var(--neutral-500)] mt-1">
                Password must be at least 6 characters long
              </p>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              {loading && <div className="loading-spinner"></div>}
              {loading ? "Creating Account..." : "Sign Up"}
            </button>
          </form>

          {/* Footer */}
          <div className="mt-8 pt-6 border-t border-[var(--neutral-200)] text-center">
            <p
              className={`text-sm ${
                theme === "light"
                  ? "text-[var(--neutral-600)]"
                  : "text-gray-400"
              }`}
            >
              Already have an account?{" "}
              <button
                onClick={onNavigateToLogin}
                className="text-[var(--primary)] hover:text-[var(--primary)]/80 font-medium transition-colors duration-200"
              >
                Sign In
              </button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignupForm;
