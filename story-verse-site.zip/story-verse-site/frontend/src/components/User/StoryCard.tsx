import React from "react";
import { Heart, Clock, BookOpen } from "lucide-react";
import { Story } from "../../types";
import { useApp } from "../../context/AppContext";

interface StoryCardProps {
  story: Story;
  onClick: () => void;
  showProgress?: boolean;
}

const StoryCard: React.FC<StoryCardProps> = ({
  story,
  onClick,
  showProgress = false,
}) => {
  const { state, toggleFavorite } = useApp();

  const isFavorite = state.favorites.some((f) => f.story_id === story.id);
  const progress = state.readingProgress.find((p) => p.story_id === story.id);

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleFavorite(story.id);
  };

  return (
    <div className="card-story group" onClick={onClick}>
      <div className="relative">
        <img
          src={
            story.cover_url ||
            "https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=400"
          }
          alt={story.title}
          className="w-full h-40 sm:h-48 object-cover"
        />
        <button
          onClick={handleFavoriteClick}
          className={`absolute top-2 right-2 sm:top-3 sm:right-3 p-1.5 sm:p-2 rounded-full transition-all duration-200 ${
            isFavorite
              ? "bg-[var(--error)] text-white"
              : "bg-white/90 text-[var(--neutral-600)] hover:bg-white"
          }`}
        >
          <Heart
            className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${
              isFavorite ? "fill-current" : ""
            }`}
          />
        </button>

        {showProgress && progress && (
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2 sm:p-3">
            <div className="flex items-center gap-1.5 sm:gap-2 text-white text-xs sm:text-sm">
              <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>{Math.round(progress.progress_percent)}% complete</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-3 sm:p-4">
        <h3 className="font-semibold text-base sm:text-lg text-[var(--neutral-800)] mb-2 line-clamp-2 group-hover:text-[var(--primary)] transition-colors duration-200">
          {story.title}
        </h3>

        {story.author && (
          <p className="text-xs sm:text-sm text-[var(--neutral-500)] mb-2 editorial-text">
            by {story.author}
          </p>
        )}

        <p className="text-xs sm:text-sm text-[var(--neutral-600)] line-clamp-3 leading-relaxed">
          {story.description}
        </p>

        <div className="flex items-center justify-between mt-3 sm:mt-4 pt-2 sm:pt-3 border-t border-[var(--neutral-100)]">
          <div className="flex items-center gap-1.5 sm:gap-2 text-[var(--neutral-500)]">
            <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="text-xs sm:text-sm">Story</span>
          </div>

          {story.status === "draft" && (
            <span className="px-1.5 sm:px-2 py-0.5 sm:py-1 bg-[var(--tertiary)] text-white text-xs rounded-full">
              Draft
            </span>
          )}
        </div>
      </div>

      {showProgress && progress && (
        <div className="px-3 sm:px-4 pb-3 sm:pb-4">
          <div className="w-full bg-[var(--neutral-200)] rounded-full h-1.5 sm:h-2">
            <div
              className="progress-bar h-1.5 sm:h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress.progress_percent}%` }}
            ></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StoryCard;
