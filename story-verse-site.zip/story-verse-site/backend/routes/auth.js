const express = require('express');
const { login, logout, signup } = require('../controllers/authController'); // Make sure signup is imported

const router = express.Router();

router.post('/login', login);
router.post('/logout', logout);
router.post('/signup', signup); // This line must exist

module.exports = router;