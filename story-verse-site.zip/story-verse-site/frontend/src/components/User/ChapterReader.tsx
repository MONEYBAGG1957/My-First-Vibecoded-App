import React, { useState, useEffect, useRef } from "react";
import {
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Settings,
  BookOpen,
  Loader,
} from "lucide-react";
import { useApp } from "../../context/AppContext";
import { ReadingProgress, Chapter } from "../../types";

interface ChapterReaderProps {
  storyId: string;
  chapterId: string;
  onBack: () => void;
  onChapterChange?: (chapterId: string) => void; // Add this prop
}

const ChapterReader: React.FC<ChapterReaderProps> = ({
  storyId,
  chapterId,
  onBack,
  onChapterChange, // Add this prop
}) => {
  const { state, updateProgress } = useApp();
  const [readingProgress, setReadingProgress] = useState(0);
  const [fontSize, setFontSize] = useState(18);
  const [showSettings, setShowSettings] = useState(false);
  const [chapter, setChapter] = useState<Chapter | null>(null);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const contentRef = useRef<HTMLDivElement | null>(null);

  const story = state.stories.find((s) => s.id === storyId);

  // Fetch all chapters for the story
  useEffect(() => {
    const fetchChapters = async () => {
      try {
        const token = localStorage.getItem("token");
        const headers: HeadersInit = {
          "Content-Type": "application/json",
        };

        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }

        const response = await fetch(
          `http://localhost:5000/api/stories/${storyId}/chapters`,
          { headers }
        );

        if (response.ok) {
          const data = await response.json();
          if (data.status === "success") {
            setChapters(data.data.chapters);
          }
        }
      } catch (err) {
        console.error("Error fetching chapters:", err);
      }
    };

    fetchChapters();
  }, [storyId]);

  // Fetch current chapter data
  useEffect(() => {
    const fetchChapter = async () => {
      try {
        setLoading(true);
        setError(null);

        const token = localStorage.getItem("token");
        const headers: HeadersInit = {
          "Content-Type": "application/json",
        };

        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }

        const response = await fetch(
          `http://localhost:5000/api/stories/${storyId}/chapters/${chapterId}`,
          { headers }
        );

        if (!response.ok) {
          throw new Error("Failed to fetch chapter");
        }

        const data = await response.json();

        if (data.status === "success") {
          setChapter(data.data.chapter);
        } else {
          throw new Error(data.message || "Failed to load chapter");
        }
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load chapter");
        console.error("Error fetching chapter:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchChapter();
  }, [storyId, chapterId]);

  // Handle scroll for reading progress
  useEffect(() => {
    const handleScroll = () => {
      const element = contentRef.current;
      if (element) {
        const scrollTop = element.scrollTop;
        const scrollHeight = element.scrollHeight - element.clientHeight;
        const progress = Math.round((scrollTop / scrollHeight) * 100);
        setReadingProgress(Math.max(0, Math.min(100, progress || 0)));
      }
    };

    const element = contentRef.current;
    if (element) {
      element.addEventListener("scroll", handleScroll);
      return () => element.removeEventListener("scroll", handleScroll);
    }
  }, [chapter]);

  // Save reading progress
  useEffect(() => {
    if (readingProgress > 0 && chapter) {
      const progress: ReadingProgress = {
        id: `${storyId}-${chapterId}`,
        user_id: state.user?.id || "",
        story_id: storyId,
        chapter_id: chapterId,
        progress_percent: readingProgress,
        last_read: new Date().toISOString(),
      };
      updateProgress(progress);
    }
  }, [
    readingProgress,
    storyId,
    chapterId,
    state.user?.id,
    updateProgress,
    chapter,
  ]);

  // Navigation functions
  const currentChapterIndex = chapters.findIndex((ch) => ch.id === chapterId);
  const hasNextChapter = currentChapterIndex < chapters.length - 1;
  const hasPreviousChapter = currentChapterIndex > 0;

  const handleNextChapter = () => {
    if (hasNextChapter && onChapterChange) {
      const nextChapter = chapters[currentChapterIndex + 1];
      onChapterChange(nextChapter.id);
    }
  };

  const handlePreviousChapter = () => {
    if (hasPreviousChapter && onChapterChange) {
      const prevChapter = chapters[currentChapterIndex - 1];
      onChapterChange(prevChapter.id);
    }
  };

  // Story not found
  if (!story) {
    return (
      <div className="flex-1 bg-dark flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-[var(--neutral-600)] mb-4">
            Chapter not found
          </h2>
          <button onClick={onBack} className="btn-primary">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // Loading state
  if (loading) {
    return (
      <div className="flex-1 bg-dark flex items-center justify-center">
        <Loader className="animate-spin w-6 h-6 text-[var(--neutral-600)]" />
      </div>
    );
  }

  // Error state
  if (error) {
    return (
      <div className="flex-1 bg-dark flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button onClick={onBack} className="btn-primary">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // No chapter loaded
  if (!chapter) {
    return null;
  }

  return (
    <div className="flex-1 bg-dark flex flex-col h-screen">
      {/* Header */}
      <div className="bg-dark border-b border-[var(--neutral-200)] p-3 sm:p-4 flex items-center justify-between sticky top-0 z-10">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 sm:gap-2 text-[var(--neutral-600)] hover:text-[var(--primary)] transition-colors duration-200"
        >
          <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="hidden sm:inline text-sm sm:text-base">
            Back to Story
          </span>
        </button>

        <div className="flex items-center gap-1.5 sm:gap-2 text-[var(--neutral-600)] max-w-[50%]">
          <BookOpen className="w-4 h-4 sm:w-5 sm:h-5 flex-shrink-0" />
          <span className="text-xs sm:text-sm font-medium truncate">
            {story.title}
          </span>
        </div>

        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-1.5 sm:p-2 text-[var(--neutral-600)] hover:text-[var(--primary)] transition-colors duration-200"
        >
          <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
        </button>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-[var(--neutral-200)] h-1">
        <div
          className="progress-bar h-1 transition-all duration-300"
          style={{ width: `${readingProgress}%` }}
        ></div>
      </div>

      {/* Settings Panel */}
      {showSettings && (
        <div className="bg-[var(--neutral-50)] border-b border-[var(--neutral-200)] p-3 sm:p-4">
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            <span className="text-xs sm:text-sm font-medium text-[var(--neutral-700)]">
              Font Size:
            </span>
            <button
              onClick={() => setFontSize(Math.max(14, fontSize - 2))}
              className="px-2 sm:px-3 py-1 bg-dark border border-[var(--neutral-300)] rounded hover:bg-[var(--neutral-50)] text-sm"
            >
              A-
            </button>
            <span className="text-xs sm:text-sm text-[var(--neutral-600)]">
              {fontSize}px
            </span>
            <button
              onClick={() => setFontSize(Math.min(24, fontSize + 2))}
              className="px-2 sm:px-3 py-1 bg-dark border border-[var(--neutral-300)] rounded hover:bg-[var(--neutral-50)] text-sm"
            >
              A+
            </button>
          </div>
        </div>
      )}

      {/* Chapter Content */}
      <div
        id="chapter-content"
        ref={contentRef}
        className="flex-1 overflow-y-auto reading-content p-4 sm:p-6 lg:p-8"
      >
        <div className="max-w-4xl mx-auto">
          <h1
            className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-6 sm:mb-8 text-center"
            style={{ fontSize: `${Math.min(fontSize + 6, 32)}px` }}
          >
            Chapter {chapter.chapter_number}: {chapter.title}
          </h1>

          <div
            className="reading-text text-[var(--neutral-800)] leading-relaxed space-y-4 sm:space-y-6 mb-20"
            style={{ fontSize: `${fontSize}px`, lineHeight: 1.8 }}
          >
            {chapter.content
              ?.split("\n\n")
              .map((paragraph: string, index: number) => (
                <p key={index} className="text-justify">
                  {paragraph}
                </p>
              ))}
          </div>
        </div>
      </div>

      {/* Chapter Navigation */}
      <div className="chapter-nav flex items-center justify-between p-4 bg-[var(--neutral-50)] border-t border-[var(--neutral-200)]">
        <button
          onClick={handlePreviousChapter}
          disabled={!hasPreviousChapter}
          className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-3 rounded ${
            hasPreviousChapter
              ? "btn-primary"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          } transition-colors duration-200`}
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="hidden sm:inline">Previous</span>
        </button>

        <div className="text-center">
          <p className="text-xs sm:text-sm text-[var(--neutral-600)]">
            Chapter {chapter.chapter_number} of {chapters.length}
          </p>
          <p className="text-xs text-[var(--neutral-500)]">
            {readingProgress}% complete
          </p>
        </div>

        <button
          onClick={handleNextChapter}
          disabled={!hasNextChapter}
          className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-3 rounded ${
            hasNextChapter
              ? "btn-primary"
              : "bg-gray-300 text-gray-500 cursor-not-allowed"
          } transition-colors duration-200`}
        >
          <span className="hidden sm:inline">Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};

export default ChapterReader;
