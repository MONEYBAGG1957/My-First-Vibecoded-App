import React, { useState } from "react";
import { BookOpen, Eye, EyeOff } from "lucide-react";
import { User } from "../../types";
import { useTheme } from "../../context/ThemeContext";

interface LoginFormProps {
  onLogin: (user: User) => void;
  onNavigateToSignup?: () => void;
}

const LoginForm: React.FC<LoginFormProps> = ({
  onLogin,
  onNavigateToSignup,
}) => {
  const { theme } = useTheme();

  const [formData, setFormData] = useState({
    email: "",
    password: "",
    isAdmin: false,
  });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: formData.email,
          password: formData.password,
        }),
      });

      // ✅ FIXED: Proper error handling
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = "Login failed";

        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
        }

        throw new Error(errorMessage);
      }

      const data = await response.json();

      // Store token in localStorage
      localStorage.setItem("token", data.token);

      // Pass user data to parent component
      onLogin(data.data.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async (role: "user" | "admin") => {
    setLoading(true);
    setError("");

    try {
      // Use demo credentials for testing
      const demoCredentials = {
        user: { email: "moneybagg123@gmail.com", password: "demo123" },
        admin: { email: "admin@storyverse.com", password: "admin123" },
      };

      // ✅ FIXED: Use the correct backend URL with port 5000
      const response = await fetch("http://localhost:5000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(demoCredentials[role]),
      });

      // ✅ FIXED: Proper error handling for demo login
      if (!response.ok) {
        const errorText = await response.text();
        let errorMessage = "Demo login failed";

        try {
          const errorData = JSON.parse(errorText);
          errorMessage = errorData.message || errorMessage;
        } catch {
          errorMessage = errorText || errorMessage;
          console.log(errorMessage);
        }

        // Fall back to mock data if demo users don't exist
        console.warn("Demo login failed, using mock data");
        const mockUser: User = {
          id: Date.now().toString(),
          email:
            role === "admin" ? "admin@storyverse.com" : "reader@storyverse.com",
          name: role === "admin" ? "Admin User" : "Demo Reader",
          role,
          created_at: new Date().toISOString(),
        };
        onLogin(mockUser);
        return;
      }

      const data = await response.json();
      localStorage.setItem("token", data.token);
      onLogin(data.data.user);
    } catch (err) {
      console.log(err);
      // Fall back to mock data on network error
      console.warn("Network error, using mock data");
      const mockUser: User = {
        id: Date.now().toString(),
        email:
          role === "admin" ? "admin@storyverse.com" : "reader@storyverse.com",
        name: role === "admin" ? "Admin User" : "Demo Reader",
        role,
        created_at: new Date().toISOString(),
      };
      onLogin(mockUser);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className={`min-h-screen flex items-center justify-center p-4 ${
        theme === "light"
          ? "bg-white"
          : "bg-gradient-to-br from-neutral-950 to-neutral-900"
      }`}
    >
      <div className="max-w-md w-full">
        <div
          className={`rounded-2xl p-8 border shadow-xl ${
            theme === "light"
              ? "bg-white border-[var(--primary)] shadow-none"
              : "bg-neutral-900 border-[var(--primary)] shadow-[0_0_15px_var(--primary)]"
          }`}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-[var(--primary)] rounded-2xl flex items-center justify-center mx-auto mb-4">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-[var(--primary)] font-['Playfair_Display'] mb-2">
              Welcome to StoryVerse
            </h1>
            <p className="text-[var(--neutral-600)]">
              Discover amazing stories and continue your reading journey
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-800 rounded-lg border border-red-200">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                Email Address
              </label>
              <input
                type="email"
                required
                className="input-field"
                placeholder="Enter your email"
                value={formData.email}
                onChange={(e) =>
                  setFormData({ ...formData, email: e.target.value })
                }
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  className="input-field pr-12"
                  placeholder="Enter your password"
                  value={formData.password}
                  onChange={(e) =>
                    setFormData({ ...formData, password: e.target.value })
                  }
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-500)] hover:text-[var(--primary)]"
                >
                  {showPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {/* <div className="flex items-center">
              <input
                type="checkbox"
                id="admin"
                checked={formData.isAdmin}
                style={{ accentColor: "var(--primary)" }}
                onChange={(e) =>
                  setFormData({ ...formData, isAdmin: e.target.checked })
                }
                className="w-4 h-4 text-[var(--primary)] bg-gray-100 border-gray-300 rounded focus:ring-[var(--secondary)]"
              />
              <label
                htmlFor="admin"
                className="ml-2 text-sm text-[var(--neutral-700)]"
              >
                Sign in as Administrator
              </label>
            </div> */}

            <button
              type="submit"
              disabled={loading}
              style={{ marginTop: "2.5rem" }}
              className="relative btn-primary w-full flex items-center justify-center py-3"
            >
              {/* spinner is absolutely positioned and removed from flow */}
              {loading && (
                <span
                  className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center justify-center"
                  style={{ width: 24, height: 24 }} // fixed size so it never changes button height
                >
                  <div className="loading-spinner w-5 h-5" />
                </span>
              )}

              {/* centered text — never moves when spinner appears */}
              <span className="text-center">
                {loading ? "Signing In..." : "Sign In"}
              </span>
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-[var(--neutral-200)]">
            <p className="text-center text-sm text-[var(--neutral-600)] mb-4">
              Try the demo without signing up:
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => handleDemoLogin("user")}
                disabled={loading}
                className="btn-tertiary flex-1 text-sm"
              >
                Demo Reader
              </button>
              <button
                onClick={() => handleDemoLogin("admin")}
                disabled={loading}
                className="btn-secondary flex-1 text-sm"
              >
                Demo Admin
              </button>
            </div>

            <div className="mt-6 pt-4 border-t border-[var(--neutral-200)] text-center">
              <p className="text-sm text-[var(--neutral-600)]">
                Don't have an account?{" "}
                <button
                  onClick={onNavigateToSignup}
                  className="text-[var(--primary)] hover:text-[var(--primary)]/80 font-medium transition-colors duration-200"
                >
                  Sign Up
                </button>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
