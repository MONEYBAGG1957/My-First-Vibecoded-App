import React, { useState, useRef, useEffect } from "react";
import {
  ArrowLeft,
  Upload,
  X,
  Plus,
  Trash2,
  Save,
  FileText,
} from "lucide-react";
import { useApp } from "../../context/AppContext";
import { Story } from "../../types";

interface StoryFormProps {
  story?: Story | null;
  onClose: () => void;
  onSave: (savedStory?: Story) => void;
  cameFrom?: string;
}

interface FormChapter {
  id: string;
  title: string;
  content: string;
  chapter_number: number;
}

const StoryForm: React.FC<StoryFormProps> = ({
  story,
  onClose,
  onSave,
  cameFrom,
}) => {
  const { addStory, updateStory } = useApp();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    title: story?.title || "",
    description: story?.description || "",
    author: story?.author || "",
    cover_url: story?.cover_url || "",
  });

  const [chapters, setChapters] = useState<FormChapter[]>([
    { id: "1", title: "", content: "", chapter_number: 1 },
  ]);

  const [loading, setLoading] = useState(false);

  // Smart back button handler
  const handleBack = () => {
    if (cameFrom === "sidebar") {
      window.history.back();
    } else {
      onClose();
    }
  };

  // In the loadChapters function, fix the headers:
  useEffect(() => {
    const loadChapters = async () => {
      if (story && story.id) {
        try {
          console.log(
            "📖 Loading chapters for story:",
            story.id,
            "Status:",
            story.status
          );

          const token = localStorage.getItem("token");
          console.log("🔑 Token available:", !!token); // Check if token exists

          // FIX: Properly format the headers
          const headers: HeadersInit = {
            "Content-Type": "application/json",
          };

          if (token) {
            headers.Authorization = `Bearer ${token}`;
          }

          const response = await fetch(
            `http://localhost:5000/api/stories/${story.id}`,
            {
              headers: headers, // Use the properly formatted headers
            }
          );

          console.log("📡 API Response status:", response.status);

          if (response.ok) {
            const data = await response.json();
            console.log("📦 API Response data:", data);

            if (data.status === "success" && data.data.story.chapters) {
              console.log(
                "✅ Chapters found:",
                data.data.story.chapters.length
              );
              const loadedChapters = data.data.story.chapters.map(
                (chap: any, index: number) => ({
                  id: chap._id || chap.id || `chapter-${index}`,
                  title: chap.title || "",
                  content: chap.content || "",
                  chapter_number: chap.chapter_number || index + 1,
                })
              );

              setChapters(loadedChapters);
            } else {
              console.log("❌ No chapters in response or API error");
            }
          } else {
            console.error("❌ API request failed:", response.status);
            // Try to get the error message from response
            const errorData = await response.json().catch(() => null);
            console.error("Error details:", errorData);
          }
        } catch (error) {
          console.error("❌ Error fetching chapters:", error);
        }
      } else if (story && story.chapters) {
        console.log("📖 Using chapters from story prop");
        setChapters(
          story.chapters.map((chap: any, index: number) => ({
            id: chap.id || `chapter-${index}`,
            title: chap.title || "",
            content: chap.content || "",
            chapter_number: chap.chapter_number || index + 1,
          }))
        );
      }
    };

    loadChapters();
  }, [story?.id]);

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleCoverUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert("Image size should be less than 5MB");
        return;
      }

      if (!file.type.startsWith("image/")) {
        alert("Please select a valid image file");
        return;
      }

      try {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          setFormData((prev) => ({ ...prev, cover_url: result }));
        };
        reader.onerror = () => {
          throw new Error("Failed to read file");
        };
        reader.readAsDataURL(file);
      } catch (error) {
        console.error("Error processing image:", error);
        alert("Error processing image. Please try another file.");
      }
    }
  };

  const addChapter = () => {
    const newChapter = {
      id: Date.now().toString(),
      title: "",
      content: "",
      chapter_number: chapters.length + 1,
    };
    setChapters((prev) => [...prev, newChapter]);
  };

  const removeChapter = (chapterId: string) => {
    if (chapters.length === 1) return;
    setChapters((prev) =>
      prev
        .filter((ch) => ch.id !== chapterId)
        .map((ch, index) => ({
          ...ch,
          chapter_number: index + 1,
        }))
    );
  };

  const updateChapter = (chapterId: string, field: string, value: string) => {
    setChapters((prev) =>
      prev.map((ch) => (ch.id === chapterId ? { ...ch, [field]: value } : ch))
    );
  };

  const handleSave = async (status: "draft" | "published") => {
    console.log("Starting save process...");

    // Validate main story fields
    if (!formData.title.trim()) {
      alert("Please enter a story title");
      return;
    }

    // Validate chapters more thoroughly
    const validChapters = chapters.filter(
      (chapter) => chapter.title.trim() && chapter.content.trim()
    );

    if (validChapters.length === 0) {
      alert("Please add at least one chapter with title and content");
      return;
    }

    // Check for chapters with title but no content (or vice versa)
    const incompleteChapters = chapters.filter(
      (chapter) =>
        (chapter.title.trim() && !chapter.content.trim()) ||
        (!chapter.title.trim() && chapter.content.trim())
    );

    if (incompleteChapters.length > 0) {
      alert(
        "Please make sure all chapters have both title and content filled out"
      );
      return;
    }

    // Additional validation for published stories
    if (status === "published") {
      if (!formData.description.trim()) {
        alert("Please add a description before publishing");
        return;
      }

      if (!formData.cover_url) {
        const confirmPublish = window.confirm(
          "You haven't added a cover image. Are you sure you want to publish without a cover?"
        );
        if (!confirmPublish) {
          return;
        }
      }
    }

    setLoading(true);

    const storyData: any = {
      title: formData.title.trim(),
      description: formData.description.trim(),
      author: formData.author.trim() || "Anonymous",
      cover_url: formData.cover_url || "",
      status,
      chapters: validChapters.map((chapter) => ({
        title: chapter.title.trim(),
        content: chapter.content.trim(),
        chapter_number: chapter.chapter_number,
      })),
    };

    try {
      console.log("Sending story data:", storyData);

      let savedStory;
      if (story) {
        storyData.id = story.id;
        savedStory = await updateStory(storyData);
        console.log("Story updated:", savedStory);
      } else {
        savedStory = await addStory(storyData);
        console.log("Story created:", savedStory);
      }

      console.log("Calling onSave callback...");
      if (onSave) {
        onSave(savedStory);
      } else {
        console.log("No onSave callback, calling onClose");
        onClose();
      }
    } catch (error) {
      console.error("Error saving story:", error);
      alert("Failed to save story. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 bg-[var(--bg-primary)] overflow-y-auto">
      <div className="p-8">
        {/* Header */}
        <div className="mb-8">
          {/* Back Button - UPDATED */}
          <div className="mb-6">
            <button
              onClick={handleBack}
              className="flex items-center gap-2 text-[var(--neutral-600)] hover:text-[var(--primary)] transition-colors duration-200"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Back</span>
            </button>
          </div>

          {/* Title Section */}
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-[var(--text-primary)] font-['Playfair_Display'] mb-2">
              {story ? "Edit Story" : "Create New Story"}
            </h1>
            <p className="text-lg text-[var(--text-secondary)]">
              {story
                ? "Update your story details and content"
                : "Craft your next masterpiece"}
            </p>
          </div>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {/* Basic Information */}
          <div className="bg-[var(--bg-secondary)] rounded-xl shadow-sm border border-[var(--border-color)] p-6">
            <h2 className="text-2xl font-semibold text-[var(--text-primary)] font-['Playfair_Display'] mb-6">
              Basic Information
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Cover Upload */}
              <div>
                <label className="block text-sm font-medium text-[var(--neutral-700)] mb-3">
                  Story Cover
                </label>
                <div className="relative">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full h-48 border-2 border-dashed border-[var(--neutral-300)] rounded-lg hover:border-[var(--primary)] transition-colors duration-200 cursor-pointer relative overflow-hidden group"
                  >
                    {formData.cover_url ? (
                      <img
                        src={formData.cover_url}
                        alt="Cover preview"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex flex-col items-center justify-center h-full text-[var(--neutral-500)] group-hover:text-[var(--primary)]">
                        <Upload className="w-8 h-8 mb-2" />
                        <span className="text-sm">Upload Cover</span>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                      <Upload className="w-6 h-6 text-white" />
                    </div>
                  </div>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleCoverUpload}
                    className="hidden"
                  />
                  {formData.cover_url && (
                    <button
                      onClick={() =>
                        setFormData((prev) => ({ ...prev, cover_url: "" }))
                      }
                      className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors duration-200"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Story Details */}
              <div className="lg:col-span-2 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                    Story Title *
                  </label>
                  <input
                    type="text"
                    required
                    className="input-field"
                    placeholder="Enter your story title..."
                    value={formData.title}
                    onChange={(e) => handleInputChange("title", e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                    Author Name
                  </label>
                  <input
                    type="text"
                    className="input-field"
                    placeholder="Enter author name..."
                    value={formData.author}
                    onChange={(e) =>
                      handleInputChange("author", e.target.value)
                    }
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                    Description
                  </label>
                  <textarea
                    className="input-field h-32 resize-none"
                    placeholder="Enter a compelling description..."
                    value={formData.description}
                    onChange={(e) =>
                      handleInputChange("description", e.target.value)
                    }
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Chapters */}
          <div className="bg-[var(--bg-secondary)] rounded-xl shadow-sm border border-[var(--border-color)] p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-semibold text-[var(--text-primary)] font-['Playfair_Display']">
                Chapters ({chapters.length})
              </h2>
              <button
                onClick={addChapter}
                className="btn-secondary flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Chapter
              </button>
            </div>

            <div className="space-y-6">
              {chapters.map((chapter) => (
                <div
                  key={chapter.id}
                  className="border border-[var(--border-color)] rounded-lg p-6 bg-[var(--bg-primary)]"
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-medium text-[var(--text-primary)]">
                      Chapter {chapter.chapter_number}
                    </h3>
                    {chapters.length > 1 && (
                      <button
                        onClick={() => removeChapter(chapter.id)}
                        className="p-2 text-[var(--neutral-500)] hover:text-[var(--error)] hover:bg-red-50 rounded-lg transition-all duration-200"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                        Chapter Title
                      </label>
                      <input
                        type="text"
                        className="input-field"
                        placeholder="Enter chapter title..."
                        value={chapter.title}
                        onChange={(e) =>
                          updateChapter(chapter.id, "title", e.target.value)
                        }
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                        Chapter Content
                      </label>
                      <textarea
                        className="input-field h-48 resize-none reading-text"
                        placeholder="Write your chapter content here..."
                        value={chapter.content}
                        onChange={(e) =>
                          updateChapter(chapter.id, "content", e.target.value)
                        }
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons - UPDATED */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pb-8">
            <button
              onClick={() => handleSave("draft")}
              disabled={loading}
              className="btn-tertiary flex items-center justify-center gap-3 min-w-[200px]"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                  Saving...
                </>
              ) : (
                <>
                  <FileText className="w-5 h-5" />
                  Save as Draft
                </>
              )}
            </button>
            <button
              onClick={() => handleSave("published")}
              disabled={loading}
              className="btn-primary flex items-center justify-center gap-3 min-w-[200px]"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                  Publishing...
                </>
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  {story?.status === "published"
                    ? "Update & Publish"
                    : "Publish Story"}
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StoryForm;
