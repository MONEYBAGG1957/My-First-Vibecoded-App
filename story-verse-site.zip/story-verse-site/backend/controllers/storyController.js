const Story = require('../models/Story');

// Get all published stories (public)
exports.getPublishedStories = async (req, res) => {
  try {
    const stories = await Story.find({ status: 'published' })
      .select('-chapters.content') // Don't send chapter content in list
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: 'success',
      results: stories.length,
      data: {
        stories
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Error fetching stories',
      error: error.message
    });
  }
};

// Get single story by ID
// In storyController.js - REPLACE the getStory function with this:
// In storyController.js - REPLACE the getStory function with this:
exports.getStory = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);

    if (!story) {
      return res.status(404).json({
        status: 'error',
        message: 'Story not found'
      });
    }

    console.log("🔍 Story found - Status:", story.status, "Created by:", story.created_by);
    console.log("👤 Current user:", req.user ? req.user._id : "No user");

    // FIX: Allow access to draft stories if the user is the owner
    if (story.status !== 'published') {
      // Check if user is authenticated AND is the story owner
      if (!req.user) {
        console.log("❌ No user authenticated - denying access to draft");
        return res.status(403).json({
          status: 'error',
          message: 'Authentication required to access draft story'
        });
      }

      if (story.created_by.toString() !== req.user._id.toString()) {
        console.log("❌ User is not the story owner - denying access");
        return res.status(403).json({
          status: 'error',
          message: 'Access denied to draft story - you are not the owner'
        });
      }

      console.log("✅ User is owner of draft - allowing access");
    }

    console.log("✅ Sending story data with chapters:", story.chapters?.length || 0);
    res.status(200).json({
      status: 'success',
      data: {
        story
      }
    });
  } catch (error) {
    console.error("❌ Error in getStory:", error);
    res.status(500).json({
      status: 'error',
      message: 'Error fetching story',
      error: error.message
    });
  }
};

// Create new story (admin only)
exports.createStory = async (req, res) => {
  try {
    const { title, description, cover_url, author, status, chapters } = req.body;

    // FIX: Proper base64 image size validation
    if (cover_url && cover_url.startsWith('data:image/')) {
      // Remove data URL prefix to get pure base64
      const base64Data = cover_url.replace(/^data:image\/\w+;base64,/, '');
      
      // Calculate approximate file size in bytes
      // Base64 size ≈ (n * 3) / 4 - padding
      const fileSize = (base64Data.length * 3) / 4;
      
      // Check if larger than 500KB (500 * 1024 bytes)
      if (fileSize > 500 * 1024) {
        return res.status(400).json({
          status: 'error',
          message: 'Cover image is too large. Please use an image under 500KB.'
        });
      }

      // Additional validation: Check if base64 is valid
      if (!/^[A-Za-z0-9+/]*={0,2}$/.test(base64Data)) {
        return res.status(400).json({
          status: 'error',
          message: 'Invalid image format.'
        });
      }
    }

    const storyData = {
      title,
      description,
      cover_url: cover_url || '',
      author: author || 'Anonymous',
      status: status || 'draft',
      chapters: chapters || [],
      created_by: req.user._id
    };

    const newStory = await Story.create(storyData);

    res.status(201).json({
      status: 'success',
      data: {
        story: newStory
      }
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        status: 'error',
        message: messages.join(', ')
      });
    }

    res.status(500).json({
      status: 'error',
      message: 'Error creating story',
      error: error.message
    });
  }
};

// Update story (admin only)
exports.updateStory = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);

    if (!story) {
      return res.status(404).json({
        status: 'error',
        message: 'Story not found'
      });
    }

    // Check if user owns the story or is admin
    if (story.created_by.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        status: 'error',
        message: 'Access denied'
      });
    }

    // FIX: Add the same image validation for updates
    if (req.body.cover_url && req.body.cover_url.startsWith('data:image/')) {
      const base64Data = req.body.cover_url.replace(/^data:image\/\w+;base64,/, '');
      const fileSize = (base64Data.length * 3) / 4;
      
      if (fileSize > 500 * 1024) {
        return res.status(400).json({
          status: 'error',
          message: 'Cover image is too large. Please use an image under 500KB.'
        });
      }
    }

    const updatedStory = await Story.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );

    res.status(200).json({
      status: 'success',
      data: {
        story: updatedStory
      }
    });
  } catch (error) {
    if (error.name === 'ValidationError') {
      const messages = Object.values(error.errors).map(err => err.message);
      return res.status(400).json({
        status: 'error',
        message: messages.join(', ')
      });
    }

    res.status(500).json({
      status: 'error',
      message: 'Error updating story',
      error: error.message
    });
  }
};

// Delete story (admin only)
exports.deleteStory = async (req, res) => {
  try {
    const story = await Story.findById(req.params.id);

    if (!story) {
      return res.status(404).json({
        status: 'error',
        message: 'Story not found'
      });
    }

    // Check if user owns the story or is admin
    if (story.created_by.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({
        status: 'error',
        message: 'Access denied'
      });
    }

    await Story.findByIdAndDelete(req.params.id);

    res.status(200).json({
      status: 'success',
      message: 'Story deleted successfully'
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Error deleting story',
      error: error.message
    });
  }
};

// Get user's stories (for admin panel)
exports.getUserStories = async (req, res) => {
  try {
    const stories = await Story.find({ created_by: req.user._id })
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: 'success',
      results: stories.length,
      data: {
        stories
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Error fetching user stories',
      error: error.message
    });
  }
};

// Get specific chapter
// In storyController.js - also update getChapter function:
exports.getChapter = async (req, res) => {
  try {
    const story = await Story.findById(req.params.storyId);
    
    if (!story) {
      return res.status(404).json({
        status: 'error',
        message: 'Story not found'
      });
    }

    const chapter = story.chapters.id(req.params.chapterId);
    
    if (!chapter) {
      return res.status(404).json({
        status: 'error',
        message: 'Chapter not found'
      });
    }

    // FIX: Same permission logic as getStory
    if (story.status !== 'published') {
      if (!req.user || story.created_by.toString() !== req.user._id.toString()) {
        return res.status(403).json({
          status: 'error',
          message: 'Access denied'
        });
      }
    }

    res.status(200).json({
      status: 'success',
      data: {
        chapter: {
          id: chapter._id,
          title: chapter.title,
          content: chapter.content,
          chapter_number: chapter.chapter_number,
          story_id: story._id,
          created_at: chapter.createdAt
        }
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Error fetching chapter',
      error: error.message
    });
  }
};

// Get all chapters for a story
exports.getStoryChapters = async (req, res) => {
  try {
    const story = await Story.findById(req.params.storyId)
      .select('chapters title status created_by');
    
    if (!story) {
      return res.status(404).json({
        status: 'error',
        message: 'Story not found'
      });
    }

    // Check access
    if (story.status !== 'published' && (!req.user || story.created_by.toString() !== req.user._id.toString())) {
      return res.status(403).json({
        status: 'error',
        message: 'Access denied'
      });
    }

    const chapters = story.chapters.map(chapter => ({
      id: chapter._id,
      title: chapter.title,
      chapter_number: chapter.chapter_number,
      story_id: story._id,
      created_at: chapter.createdAt
    }));

    res.status(200).json({
      status: 'success',
      data: {
        chapters,
        storyTitle: story.title
      }
    });
  } catch (error) {
    res.status(500).json({
      status: 'error',
      message: 'Error fetching chapters',
      error: error.message
    });
  }
};