import React, { createContext, useContext, useReducer, useEffect } from "react";
import {
  AppState,
  User,
  Story,
  Category,
  ReadingProgress,
  Favorite,
} from "../types";

interface AppContextType {
  state: AppState;
  login: (user: User) => void;
  logout: () => void;
  addStory: (story: Story) => void;
  updateStory: (story: Story) => void;
  deleteStory: (id: string) => void;
  updateProgress: (progress: ReadingProgress) => void;
  toggleFavorite: (storyId: string) => void;
  isAdmin: boolean;
  loading: boolean;
  error: string | null;
  fetchStories: () => Promise<void>;
  fetchUserStories: (userId?: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

type AppAction =
  | { type: "LOGIN"; payload: User }
  | { type: "LOGOUT" }
  | { type: "SET_STORIES"; payload: Story[] }
  | { type: "ADD_STORY"; payload: Story }
  | { type: "UPDATE_STORY"; payload: Story }
  | { type: "DELETE_STORY"; payload: string }
  | { type: "SET_CATEGORIES"; payload: Category[] }
  | { type: "UPDATE_PROGRESS"; payload: ReadingProgress }
  | { type: "TOGGLE_FAVORITE"; payload: string }
  | { type: "SET_FAVORITES"; payload: Favorite[] }
  | { type: "SET_LOADING"; payload: boolean }
  | { type: "SET_ERROR"; payload: string | null };

const initialState: AppState = {
  user: null,
  stories: [],
  categories: [],
  readingProgress: [],
  favorites: [],
};

function appReducer(state: AppState, action: AppAction): AppState {
  console.log(
    "🔄 REDUCER ACTION:",
    action.type,
    action.payload?.toString().substring(0, 50) + "..."
  );

  switch (action.type) {
    case "LOGIN":
      return { ...state, user: action.payload };
    case "LOGOUT":
      return { ...state, user: null, readingProgress: [], favorites: [] };
    case "SET_STORIES":
      return { ...state, stories: action.payload };
    case "ADD_STORY":
      return { ...state, stories: [...state.stories, action.payload] };
    case "UPDATE_STORY":
      return {
        ...state,
        stories: state.stories.map((story) =>
          story.id === action.payload.id ? action.payload : story
        ),
      };
    case "DELETE_STORY":
      return {
        ...state,
        stories: state.stories.filter((story) => story.id !== action.payload),
      };
    case "SET_CATEGORIES":
      return { ...state, categories: action.payload };
    case "UPDATE_PROGRESS":
      return {
        ...state,
        readingProgress: state.readingProgress.some(
          (p) => p.story_id === action.payload.story_id
        )
          ? state.readingProgress.map((p) =>
              p.story_id === action.payload.story_id ? action.payload : p
            )
          : [...state.readingProgress, action.payload],
      };
    case "TOGGLE_FAVORITE": {
      const existingFavorite = state.favorites.find(
        (f) => f.story_id === action.payload
      );
      if (existingFavorite) {
        return {
          ...state,
          favorites: state.favorites.filter(
            (f) => f.story_id !== action.payload
          ),
        };
      } else {
        const newFavorite: Favorite = {
          id: Date.now().toString(),
          user_id: state.user?.id || "",
          story_id: action.payload,
          created_at: new Date().toISOString(),
        };
        return {
          ...state,
          favorites: [...state.favorites, newFavorite],
        };
      }
    }
    case "SET_FAVORITES":
      return { ...state, favorites: action.payload };
    case "SET_LOADING":
      return state;
    case "SET_ERROR":
      return state;
    default:
      return state;
  }
}

// API base URL
const API_BASE = "http://localhost:5000/api";

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);

  // Helper function to get auth headers
  const getAuthHeaders = () => {
    const token = localStorage.getItem("token");
    return {
      "Content-Type": "application/json",
      ...(token && { Authorization: `Bearer ${token}` }),
    };
  };

  // Fetch all published stories (public)
  const fetchStories = async () => {
    setLoading(true);
    setError(null);
    try {
      console.log("📖 Fetching published stories from:", `${API_BASE}/stories`);

      const response = await fetch(`${API_BASE}/stories`);

      if (!response.ok) {
        throw new Error(`Failed to fetch stories: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("Published stories API response:", data);

      if (data.status === "success") {
        const stories: Story[] = data.data.stories.map((story: any) => ({
          id: story._id || story.id,
          title: story.title,
          description: story.description,
          cover_url: story.cover_url,
          author: story.author,
          status: story.status,
          created_at: story.createdAt || story.created_at,
          updated_at: story.updatedAt || story.updated_at,
          chapters: story.chapters || [],
        }));

        console.log(`📚 Loaded ${stories.length} published stories`);
        dispatch({ type: "SET_STORIES", payload: stories });
      }
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to fetch stories";
      setError(errorMessage);
      console.error("Error fetching stories:", err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch user's stories (for admin panel) - FIXED VERSION
  const fetchUserStories = async (userId?: string) => {
    // Use provided userId or fallback to state.user
    const targetUserId = userId || state.user?.id;

    if (!targetUserId) {
      console.log("No user ID provided, skipping user stories fetch");
      return;
    }

    setLoading(true);
    setError(null);
    try {
      console.log("📋 Fetching user stories for user:", targetUserId);

      const response = await fetch(`${API_BASE}/stories/user/my-stories`, {
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        throw new Error(`Failed to fetch user stories: ${response.statusText}`);
      }

      const data = await response.json();
      console.log("User stories API response:", data);

      if (data.status === "success") {
        const stories: Story[] = data.data.stories.map((story: any) => ({
          id: story._id || story.id,
          title: story.title,
          description: story.description,
          cover_url: story.cover_url,
          author: story.author,
          status: story.status,
          created_at: story.createdAt || story.created_at,
          updated_at: story.updatedAt || story.updated_at,
          chapters: story.chapters || [],
        }));

        console.log(`📋 Loaded ${stories.length} user stories`);
        dispatch({ type: "SET_STORIES", payload: stories });
      } else {
        console.error("API returned error status:", data);
        throw new Error(data.message || "Failed to fetch user stories");
      }
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to fetch user stories";
      setError(errorMessage);
      console.error("Error fetching user stories:", err);
    } finally {
      setLoading(false);
    }
  };

  // Fixed useEffect with proper initialization
  useEffect(() => {
    const initializeApp = async () => {
      console.log("🚀 Initializing app...");

      const token = localStorage.getItem("token");
      const userData = localStorage.getItem("user");

      if (token && userData) {
        try {
          const user = JSON.parse(userData);
          console.log("👤 Found stored user:", user);

          // Set user first
          dispatch({ type: "LOGIN", payload: user });

          // Pass user ID explicitly to avoid race condition
          if (user.role === "admin") {
            console.log("🛠️ Loading admin stories including drafts...");
            await fetchUserStories(user.id); // Pass the user ID directly
          } else {
            console.log("👤 Loading published stories for regular user...");
            await fetchStories();
          }
        } catch (error) {
          console.error("❌ Error parsing stored user data:", error);
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          console.log("🔄 Fallback to public stories...");
          await fetchStories();
        }
      } else {
        // No user logged in, just fetch public stories
        console.log("👤 No user logged in, loading public stories...");
        await fetchStories();
      }

      // Always set categories
      console.log("📂 Setting categories...");
      dispatch({ type: "SET_CATEGORIES", payload: mockCategories });

      console.log("✅ App initialization complete");
    };

    initializeApp();
  }, []);

  const login = (user: User) => {
    console.log("🔄 LOGIN CALLED - User role:", user.role);
    localStorage.setItem("user", JSON.stringify(user));

    dispatch({ type: "LOGIN", payload: user });

    // Pass user ID explicitly
    if (user.role === "admin") {
      console.log("📋 Fetching admin stories (including drafts)");
      fetchUserStories(user.id); // Pass the user ID
    } else {
      console.log("📖 Fetching published stories for regular user");
      fetchStories();
    }
  };

  const logout = () => {
    console.log("👋 LOGOUT CALLED");
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    // Optional: Call logout endpoint if you have one
    fetch("/api/auth/logout", {
      method: "POST",
      headers: getAuthHeaders(),
    }).catch((error) => {
      console.log("Logout API call failed:", error);
    });

    dispatch({ type: "LOGOUT" });
    // Refresh stories to show only published ones
    console.log("🔄 Loading public stories after logout");
    fetchStories();
  };

  // Create new story (API call)
  const addStory = async (story: Story) => {
    setLoading(true);
    setError(null);
    try {
      // Validate chapters before sending
      if (story.chapters) {
        const invalidChapters = story.chapters.filter(
          (chapter: any) => !chapter.title || !chapter.content
        );

        if (invalidChapters.length > 0) {
          throw new Error(
            `Some chapters are missing title or content. Please fill in all chapter fields.`
          );
        }
      }

      const storyData = {
        title: story.title,
        description: story.description,
        cover_url: story.cover_url,
        author: story.author,
        status: story.status,
        chapters: story.chapters
          ? story.chapters.map((chapter: any) => ({
              title: chapter.title,
              content: chapter.content,
              chapter_number: chapter.chapter_number,
            }))
          : [],
      };

      console.log("Sending create data:", storyData);

      const response = await fetch(`${API_BASE}/stories`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(storyData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Backend error response:", errorData);
        throw new Error(errorData.message || "Failed to create story");
      }

      const data = await response.json();

      if (data.status === "success") {
        const newStory: Story = {
          id: data.data.story._id,
          title: data.data.story.title,
          description: data.data.story.description,
          cover_url: data.data.story.cover_url,
          author: data.data.story.author,
          status: data.data.story.status,
          created_at: data.data.story.createdAt,
          updated_at: data.data.story.updatedAt,
          chapters: data.data.story.chapters || [],
        };

        console.log("✅ Story created successfully:", newStory);
        dispatch({ type: "ADD_STORY", payload: newStory });
        return newStory;
      }
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to create story";
      setError(errorMessage);
      console.error("❌ Error creating story:", err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Update story (API call)
  const updateStory = async (story: Story) => {
    setLoading(true);
    setError(null);
    try {
      // Validate that all chapters have required fields
      if (story.chapters) {
        const invalidChapters = story.chapters.filter(
          (chapter: any) => !chapter.title || !chapter.content
        );

        if (invalidChapters.length > 0) {
          throw new Error(
            `Some chapters are missing title or content. Please fill in all chapter fields.`
          );
        }
      }

      const storyData = {
        title: story.title,
        description: story.description,
        cover_url: story.cover_url,
        author: story.author,
        status: story.status,
        chapters: story.chapters
          ? story.chapters.map((chapter: any) => ({
              title: chapter.title,
              content: chapter.content,
              chapter_number: chapter.chapter_number,
              _id: chapter.id || chapter._id,
            }))
          : [],
      };

      console.log("Sending update data:", storyData);

      const response = await fetch(`${API_BASE}/stories/${story.id}`, {
        method: "PUT",
        headers: getAuthHeaders(),
        body: JSON.stringify(storyData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error("Backend error response:", errorData);
        throw new Error(errorData.message || "Failed to update story");
      }

      const data = await response.json();
      console.log("Update successful:", data);

      if (data.status === "success") {
        const updatedStory: Story = {
          id: data.data.story._id,
          title: data.data.story.title,
          description: data.data.story.description,
          cover_url: data.data.story.cover_url,
          author: data.data.story.author,
          status: data.data.story.status,
          created_at: data.data.story.createdAt,
          updated_at: data.data.story.updatedAt,
          chapters: data.data.story.chapters || [],
        };

        console.log("✅ Story updated successfully:", updatedStory);
        dispatch({ type: "UPDATE_STORY", payload: updatedStory });
        return updatedStory;
      }
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to update story";
      setError(errorMessage);
      console.error("❌ Error updating story:", err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  // Delete story (API call)
  const deleteStory = async (id: string) => {
    setLoading(true);
    setError(null);
    try {
      console.log("🗑️ Deleting story with ID:", id);

      const response = await fetch(`${API_BASE}/stories/${id}`, {
        method: "DELETE",
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete story");
      }

      console.log("✅ Story deleted successfully");
      dispatch({ type: "DELETE_STORY", payload: id });
    } catch (err) {
      const errorMessage =
        err instanceof Error ? err.message : "Failed to delete story";
      setError(errorMessage);
      console.error("❌ Error deleting story:", err);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const updateProgress = (progress: ReadingProgress) => {
    console.log("📊 Updating reading progress:", progress);
    dispatch({ type: "UPDATE_PROGRESS", payload: progress });
  };

  const toggleFavorite = (storyId: string) => {
    console.log("❤️ Toggling favorite for story:", storyId);
    dispatch({ type: "TOGGLE_FAVORITE", payload: storyId });
  };

  const isAdmin = state.user?.role === "admin";

  const value: AppContextType = {
    state,
    login,
    logout,
    addStory,
    updateStory,
    deleteStory,
    updateProgress,
    toggleFavorite,
    isAdmin,
    loading,
    error,
    fetchStories,
    fetchUserStories,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}

// Mock categories
const mockCategories: Category[] = [
  { id: "1", name: "Fantasy", description: "Magical worlds and adventures" },
  {
    id: "2",
    name: "Science Fiction",
    description: "Future technology and space",
  },
  { id: "3", name: "Mystery", description: "Puzzles and suspense" },
  { id: "4", name: "Romance", description: "Love and relationships" },
  { id: "5", name: "Adventure", description: "Action and exploration" },
];
