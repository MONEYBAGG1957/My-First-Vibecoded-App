import React, { useState, useMemo } from "react";
import { Search, Filter, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import StoryCard from "./StoryCard";

interface SearchPageProps {
  onStorySelect: (storyId: string) => void;
}

const SearchPage: React.FC<SearchPageProps> = ({ onStorySelect }) => {
  const { state } = useApp();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedAuthor, setSelectedAuthor] = useState<string>("all");
  const [sortBy, setSortBy] = useState<"title" | "author" | "updated">("title");
  const [showFilters, setShowFilters] = useState(false);

  const publishedStories = state.stories.filter(
    (story) => story.status === "published"
  );

  // Get unique authors
  const authors = useMemo(() => {
    const authorSet = new Set(
      publishedStories
        .map((story) => story.author)
        .filter((author): author is string => Boolean(author))
    );
    return Array.from(authorSet).sort();
  }, [publishedStories]);

  // Filter and sort stories
  const filteredStories = useMemo(() => {
    const filtered = publishedStories.filter((story) => {
      const matchesSearch =
        story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        story.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (story.author &&
          story.author.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesCategory =
        selectedCategory === "all" || story.category_id === selectedCategory;

      const matchesAuthor =
        selectedAuthor === "all" || story.author === selectedAuthor;

      return matchesSearch && matchesCategory && matchesAuthor;
    });

    // Sort stories
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "title":
          return a.title.localeCompare(b.title);
        case "author":
          return (a.author || "").localeCompare(b.author || "");
        case "updated":
          return (
            new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
          );
        default:
          return 0;
      }
    });

    return filtered;
  }, [publishedStories, searchTerm, selectedCategory, selectedAuthor, sortBy]);

  const clearFilters = () => {
    setSearchTerm("");
    setSelectedCategory("all");
    setSelectedAuthor("all");
    setSortBy("title");
  };

  const hasActiveFilters =
    searchTerm || selectedCategory !== "all" || selectedAuthor !== "all";

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-2">
            Search Stories
          </h1>
          <p className="text-base sm:text-lg text-[var(--neutral-600)]">
            Find your next great read from our collection
          </p>
        </div>

        {/* Search Bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-4 h-4 sm:w-5 sm:h-5" />
          <input
            type="text"
            placeholder="Search by title, author, or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input-field pl-10 sm:pl-12 pr-12 text-base sm:text-lg"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] hover:text-[var(--neutral-600)]"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-4 sm:p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-[var(--neutral-800)]">
              Filters
            </h3>
            <div className="flex items-center gap-2">
              {hasActiveFilters && (
                <button
                  onClick={clearFilters}
                  className="text-sm text-[var(--primary)] hover:text-[var(--primary)]/80 transition-colors duration-200"
                >
                  Clear All
                </button>
              )}
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="lg:hidden p-2 text-[var(--neutral-600)] hover:text-[var(--primary)] transition-colors duration-200"
              >
                <Filter className="w-5 h-5" />
              </button>
            </div>
          </div>

          <div
            className={`grid grid-cols-1 lg:grid-cols-4 gap-4 ${
              showFilters ? "block" : "hidden lg:grid"
            }`}
          >
            {/* Category Filter */}
            <div>
              <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                Category
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="input-field text-sm"
              >
                <option value="all">All Categories</option>
                {state.categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Author Filter */}
            <div>
              <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                Author
              </label>
              <select
                value={selectedAuthor}
                onChange={(e) => setSelectedAuthor(e.target.value)}
                className="input-field text-sm"
              >
                <option value="all">All Authors</option>
                {authors.map((author) => (
                  <option key={author} value={author}>
                    {author}
                  </option>
                ))}
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label className="block text-sm font-medium text-[var(--neutral-700)] mb-2">
                Sort By
              </label>
              <select
                value={sortBy}
                onChange={(e) =>
                  setSortBy(e.target.value as "title" | "author" | "updated")
                }
                className="input-field text-sm"
              >
                <option value="title">Title (A-Z)</option>
                <option value="author">Author (A-Z)</option>
                <option value="updated">Recently Updated</option>
              </select>
            </div>

            {/* Results Count */}
            <div className="flex items-end">
              <div className="text-sm text-[var(--neutral-600)]">
                <span className="font-medium">{filteredStories.length}</span>{" "}
                stories found
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        {filteredStories.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {filteredStories.map((story) => (
              <StoryCard
                key={story.id}
                story={story}
                onClick={() => onStorySelect(story.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Search className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
            <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
              No stories found
            </h3>
            <p className="text-[var(--neutral-500)] mb-4">
              {searchTerm
                ? `No results for "${searchTerm}"`
                : "Try adjusting your filters to see more results"}
            </p>
            {hasActiveFilters && (
              <button onClick={clearFilters} className="btn-primary">
                Clear Filters
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPage;
