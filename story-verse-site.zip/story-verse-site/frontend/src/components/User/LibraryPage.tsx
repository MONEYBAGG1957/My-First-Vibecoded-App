import React, { useState, useMemo } from "react";
import { Clock, Heart, BookOpen, Filter } from "lucide-react";
import { useApp } from "../../context/AppContext";
import StoryCard from "./StoryCard";

interface LibraryPageProps {
  onStorySelect: (storyId: string) => void;
}

const LibraryPage: React.FC<LibraryPageProps> = ({ onStorySelect }) => {
  const { state } = useApp();
  const [activeTab, setActiveTab] = useState<
    "reading" | "completed" | "favorites"
  >("reading");
  const [sortBy, setSortBy] = useState<"recent" | "title" | "progress">(
    "recent"
  );

  // Get stories with reading progress
  const storiesWithProgress = useMemo(() => {
    return state.readingProgress
      .map((progress) => {
        const story = state.stories.find(
          (s) => s.id === progress.story_id && s.status === "published"
        );
        return story ? { story, progress } : null;
      })
      .filter(Boolean)
      .sort((a, b) => {
        switch (sortBy) {
          case "recent":
            return (
              new Date(b!.progress.last_read).getTime() -
              new Date(a!.progress.last_read).getTime()
            );
          case "title":
            return a!.story.title.localeCompare(b!.story.title);
          case "progress":
            return b!.progress.progress_percent - a!.progress.progress_percent;
          default:
            return 0;
        }
      });
  }, [state.readingProgress, state.stories, sortBy]);

  // Get currently reading stories (progress < 100%)
  const currentlyReading = storiesWithProgress.filter(
    (item) => item!.progress.progress_percent < 100
  );

  // Get completed stories (progress = 100%)
  const completedStories = storiesWithProgress.filter(
    (item) => item!.progress.progress_percent >= 100
  );

  // Get favorite stories
  const favoriteStories = useMemo(() => {
    return state.favorites
      .map((favorite) => {
        const story = state.stories.find(
          (s) => s.id === favorite.story_id && s.status === "published"
        );
        return story ? { story, favorite } : null;
      })
      .filter(Boolean)
      .sort((a, b) => {
        switch (sortBy) {
          case "recent":
            return (
              new Date(b!.favorite.created_at).getTime() -
              new Date(a!.favorite.created_at).getTime()
            );
          case "title":
            return a!.story.title.localeCompare(b!.story.title);
          default:
            return 0;
        }
      });
  }, [state.favorites, state.stories, sortBy]);

  const tabs = [
    {
      id: "reading" as const,
      label: "Currently Reading",
      icon: Clock,
      count: currentlyReading.length,
    },
    {
      id: "completed" as const,
      label: "Completed",
      icon: BookOpen,
      count: completedStories.length,
    },
    {
      id: "favorites" as const,
      label: "Favorites",
      icon: Heart,
      count: favoriteStories.length,
    },
  ];

  const getCurrentData = () => {
    switch (activeTab) {
      case "reading":
        return currentlyReading;
      case "completed":
        return completedStories;
      case "favorites":
        return favoriteStories;
      default:
        return [];
    }
  };

  const currentData = getCurrentData();

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-2">
            My Library
          </h1>
          <p className="text-base sm:text-lg text-[var(--neutral-600)]">
            Track your reading progress and manage your favorite stories
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-4 sm:p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[var(--primary)]/10 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-[var(--primary)]" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--neutral-800)]">
                  {currentlyReading.length}
                </h3>
                <p className="text-sm text-[var(--neutral-600)]">
                  Currently Reading
                </p>
              </div>
            </div>
          </div>

          <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-4 sm:p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[var(--secondary)]/10 rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-[var(--secondary)]" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--neutral-800)]">
                  {completedStories.length}
                </h3>
                <p className="text-sm text-[var(--neutral-600)]">Completed</p>
              </div>
            </div>
          </div>

          <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-4 sm:p-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-[var(--error)]/10 rounded-lg flex items-center justify-center">
                <Heart className="w-6 h-6 text-[var(--error)]" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-[var(--neutral-800)]">
                  {favoriteStories.length}
                </h3>
                <p className="text-sm text-[var(--neutral-600)]">Favorites</p>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs and Filters */}
        <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] mb-6">
          <div className="border-b border-[var(--neutral-200)]">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 sm:p-6">
              <div className="flex space-x-1 mb-4 sm:mb-0">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg font-medium transition-colors duration-200 text-sm sm:text-base ${
                        activeTab === tab.id
                          ? "bg-[var(--primary)] text-white"
                          : "text-[var(--neutral-600)] hover:text-[var(--primary)] hover:bg-[var(--neutral-50)]"
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span className="hidden sm:inline">{tab.label}</span>
                      <span className="sm:hidden">
                        {tab.label.split(" ")[0]}
                      </span>
                      <span className="bg-white/20 text-xs px-1.5 py-0.5 rounded-full">
                        {tab.count}
                      </span>
                    </button>
                  );
                })}
              </div>

              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4 text-[var(--neutral-500)]" />
                <select
                  value={sortBy}
                  onChange={(e) =>
                    setSortBy(e.target.value as "recent" | "title" | "progress")
                  }
                  className="text-sm border border-[var(--neutral-300)] rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-[var(--secondary)] focus:border-transparent"
                >
                  <option value="recent">
                    Recently {activeTab === "favorites" ? "Added" : "Read"}
                  </option>
                  <option value="title">Title (A-Z)</option>
                  {activeTab !== "favorites" && (
                    <option value="progress">Progress</option>
                  )}
                </select>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-4 sm:p-6">
            {currentData.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
                {currentData.map((item) => (
                  <StoryCard
                    key={item!.story.id}
                    story={item!.story}
                    onClick={() => onStorySelect(item!.story.id)}
                    showProgress={activeTab !== "favorites"}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                {activeTab === "reading" && (
                  <>
                    <Clock className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
                      No stories in progress
                    </h3>
                    <p className="text-[var(--neutral-500)]">
                      Start reading a story to see your progress here
                    </p>
                  </>
                )}
                {activeTab === "completed" && (
                  <>
                    <BookOpen className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
                      No completed stories
                    </h3>
                    <p className="text-[var(--neutral-500)]">
                      Finish reading a story to see it here
                    </p>
                  </>
                )}
                {activeTab === "favorites" && (
                  <>
                    <Heart className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
                      No favorite stories
                    </h3>
                    <p className="text-[var(--neutral-500)]">
                      Add stories to your favorites to see them here
                    </p>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default LibraryPage;
