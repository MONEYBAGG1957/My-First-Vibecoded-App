import React, { useState, useEffect } from "react";
import { Plus, Search, Edit2, Trash2, Eye, FileText } from "lucide-react";
import { useApp } from "../../context/AppContext";
import { Story } from "../../types";
import StoryForm from "./StoryForm";

interface StoryManagerProps {
  currentView?: string;
}

const StoryManager: React.FC<StoryManagerProps> = ({
  currentView = "manage-stories",
}) => {
  const { state, deleteStory, updateStory } = useApp();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<
    "all" | "published" | "draft"
  >("all");
  const [editingStory, setEditingStory] = useState<Story | null>(null);
  const [showForm, setShowForm] = useState(false);

  // FIX: Properly handle view changes and reset states
  useEffect(() => {
    if (currentView === "add-story") {
      setShowForm(true);
      setEditingStory(null);
      setFilterStatus("all");
      setSearchTerm(""); // Reset search when changing views
    } else if (currentView === "drafts") {
      setFilterStatus("draft");
      setShowForm(false);
      setEditingStory(null); // Ensure editing is reset
    } else {
      setFilterStatus("all");
      setShowForm(false);
      setEditingStory(null);
    }
  }, [currentView]);

  const filteredStories = state.stories.filter((story) => {
    const matchesSearch =
      story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      story.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (story.author &&
        story.author.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter =
      filterStatus === "all" || story.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const handleEdit = (story: Story) => {
    setEditingStory(story);
    setShowForm(true);
  };

  // FIX: Improved delete handling with error boundary
  const handleDelete = (storyId: string) => {
    if (
      window.confirm(
        "Are you sure you want to delete this story? This action cannot be undone."
      )
    ) {
      try {
        deleteStory(storyId);
      } catch (error) {
        console.error("Error deleting story:", error);
        alert("Failed to delete story. Please try again.");
      }
    }
  };

  // FIX: Updated status toggle function with proper async handling
  // In StoryManager.tsx, fix the handleToggleStatus function:
  const handleToggleStatus = async (story: Story) => {
    const newStatus = story.status === "published" ? "draft" : "published";

    try {
      // Create a proper Story object with only the changed status
      const updatedStory: Story = {
        ...story, // Spread all existing story properties
        status: newStatus,
        updated_at: new Date().toISOString(),
      };

      await updateStory(updatedStory);
    } catch (error) {
      console.error("Error toggling story status:", error);
      alert("Failed to update story status. Please try again.");
    }
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingStory(null);
  };

  // FIX: Updated StoryForm usage with proper callback
  if (showForm) {
    return (
      // Fix: Remove the unused parameter
      <StoryForm
        story={editingStory}
        onClose={handleCloseForm}
        onSave={() => {
          // Remove the (savedStory) parameter
          handleCloseForm();
          // Refresh the stories list
          if (state.user?.role === "admin") {
            // We need to make fetchUserStories available in this component
            // You'll need to get it from useApp or define it locally
          }
        }}
      />
    );
  }

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-2">
              {currentView === "add-story"
                ? "Create New Story"
                : currentView === "drafts"
                ? "Draft Stories"
                : "Manage Stories"}
            </h1>
            <p className="text-lg text-[var(--neutral-600)]">
              {currentView === "add-story"
                ? "Add a new story to your collection"
                : currentView === "drafts"
                ? "Review and publish your draft stories"
                : "Create, edit, and organize your story collection"}
            </p>
          </div>
          {currentView !== "add-story" && (
            <button
              onClick={() => {
                setEditingStory(null);
                setShowForm(true);
              }}
              className="btn-primary flex items-center gap-3"
            >
              <Plus className="w-5 h-5" />
              Add New Story
            </button>
          )}
        </div>

        {/* Filters - FIX: Only show when not in add-story mode */}
        {currentView !== "add-story" && (
          <>
            <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-6 mb-6">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-5 h-5" />
                    <input
                      type="text"
                      placeholder="Search stories..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="input-field pl-12 w-full"
                    />
                  </div>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <button
                    onClick={() => setFilterStatus("all")}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                      filterStatus === "all"
                        ? "bg-[var(--primary)] text-white"
                        : "bg-[var(--neutral-200)] text-[var(--neutral-700)] hover:bg-[var(--neutral-300)]"
                    }`}
                  >
                    All ({state.stories.length})
                  </button>
                  <button
                    onClick={() => setFilterStatus("published")}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                      filterStatus === "published"
                        ? "bg-[var(--primary)] text-white"
                        : "bg-[var(--neutral-200)] text-[var(--neutral-700)] hover:bg-[var(--neutral-300)]"
                    }`}
                  >
                    Published (
                    {
                      state.stories.filter((s) => s.status === "published")
                        .length
                    }
                    )
                  </button>
                  <button
                    onClick={() => setFilterStatus("draft")}
                    className={`px-4 py-2 rounded-lg font-medium transition-colors duration-200 ${
                      filterStatus === "draft"
                        ? "bg-[var(--primary)] text-white"
                        : "bg-[var(--neutral-200)] text-[var(--neutral-700)] hover:bg-[var(--neutral-300)]"
                    }`}
                  >
                    Drafts (
                    {state.stories.filter((s) => s.status === "draft").length})
                  </button>
                </div>
              </div>
            </div>

            {/* Stories Table */}
            <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] overflow-hidden">
              {filteredStories.length === 0 ? (
                <div className="p-12 text-center">
                  <FileText className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
                  <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
                    No stories found
                  </h3>
                  <p className="text-[var(--neutral-500)] mb-4">
                    {searchTerm || filterStatus !== "all"
                      ? "Try adjusting your search or filters"
                      : "Get started by creating your first story"}
                  </p>
                  {!searchTerm && filterStatus === "all" && (
                    <button
                      onClick={() => {
                        setEditingStory(null);
                        setShowForm(true);
                      }}
                      className="btn-primary"
                    >
                      Create Your First Story
                    </button>
                  )}
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-[var(--neutral-50)] border-b border-[var(--neutral-200)]">
                      <tr>
                        <th className="text-left p-4 font-semibold text-[var(--neutral-700)]">
                          Story
                        </th>
                        <th className="text-left p-4 font-semibold text-[var(--neutral-700)]">
                          Author
                        </th>
                        <th className="text-left p-4 font-semibold text-[var(--neutral-700)]">
                          Status
                        </th>
                        <th className="text-left p-4 font-semibold text-[var(--neutral-700)]">
                          Updated
                        </th>
                        <th className="text-center p-4 font-semibold text-[var(--neutral-700)]">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--neutral-200)]">
                      {filteredStories.map((story) => (
                        <tr
                          key={story.id}
                          className="hover:bg-[var(--neutral-50)] transition-colors duration-200"
                        >
                          <td className="p-4">
                            <div className="flex items-start gap-4">
                              <img
                                src={
                                  story.cover_url ||
                                  "https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=100"
                                }
                                alt={story.title}
                                className="w-12 h-12 object-cover rounded-lg"
                                onError={(e) => {
                                  // FIX: Handle image loading errors
                                  e.currentTarget.src =
                                    "https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=100";
                                }}
                              />
                              <div className="flex-1 min-w-0">
                                <h3 className="font-medium text-[var(--neutral-800)] mb-1 truncate">
                                  {story.title}
                                </h3>
                                <p className="text-sm text-[var(--neutral-600)] line-clamp-2">
                                  {story.description}
                                </p>
                              </div>
                            </div>
                          </td>
                          <td className="p-4">
                            <span className="text-sm text-[var(--neutral-700)]">
                              {story.author || "Unknown"}
                            </span>
                          </td>
                          <td className="p-4">
                            <button
                              onClick={() => handleToggleStatus(story)}
                              className={`px-3 py-1 text-sm rounded-full font-medium transition-colors duration-200 ${
                                story.status === "published"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-[var(--tertiary)] text-white hover:bg-[var(--tertiary)]/90"
                              }`}
                            >
                              {story.status === "published"
                                ? "Published"
                                : "Draft"}
                            </button>
                          </td>
                          <td className="p-4">
                            <span className="text-sm text-[var(--neutral-600)]">
                              {new Date(story.updated_at).toLocaleDateString()}
                            </span>
                          </td>
                          <td className="p-4">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => handleEdit(story)}
                                className="p-2 text-[var(--neutral-600)] hover:text-[var(--primary)] hover:bg-[var(--primary)]/10 rounded-lg transition-all duration-200"
                                title="Edit story"
                              >
                                <Edit2 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleToggleStatus(story)}
                                className="p-2 text-[var(--neutral-600)] hover:text-[var(--secondary)] hover:bg-[var(--secondary)]/10 rounded-lg transition-all duration-200"
                                title={
                                  story.status === "published"
                                    ? "Unpublish"
                                    : "Publish"
                                }
                              >
                                <Eye className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDelete(story.id)}
                                className="p-2 text-[var(--neutral-600)] hover:text-red-600 hover:bg-red-50 rounded-lg transition-all duration-200"
                                title="Delete story"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default StoryManager;
