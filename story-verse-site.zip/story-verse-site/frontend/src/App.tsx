import { useState, useEffect } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import { ThemeProvider } from "./context/ThemeContext";
import LoginForm from "./components/Auth/LoginForm";
import Sidebar from "./components/Layout/Sidebar";
import HomePage from "./components/User/HomePage";
import StoryDetails from "./components/User/StoryDetails";
import ChapterReader from "./components/User/ChapterReader";
import Dashboard from "./components/Admin/Dashboard";
import StoryManager from "./components/Admin/StoryManager";
import SettingsPage from "./components/Settings/SettingsPage";
import SearchPage from "./components/User/SearchPage";
import LibraryPage from "./components/User/LibraryPage";
import FavoritesPage from "./components/User/FavoritesPage";
import ProfilePage from "./components/User/ProfilePage";
import SignupForm from "./components/Auth/SignupForm";

type ViewState = {
  type:
    | "home"
    | "search"
    | "story-details"
    | "chapter-reader"
    | "admin"
    | "profile"
    | "library"
    | "favorites";
  data?: { storyId?: string; chapterId?: string };
};

function AppContent() {
  const { state, login, logout, isAdmin } = useApp();
  const [currentView, setCurrentView] = useState("home");
  const [viewState, setViewState] = useState<ViewState>({ type: "home" });
  const [showSignup, setShowSignup] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [isInitialized, setIsInitialized] = useState(false);

  // Simple initialization - only runs once
  useEffect(() => {
    const initialize = () => {
      const savedView = localStorage.getItem("currentView");
      const savedViewState = localStorage.getItem("viewState");

      if (savedView) setCurrentView(savedView);
      if (savedViewState) {
        try {
          setViewState(JSON.parse(savedViewState));
        } catch (error) {
          console.error("Error parsing view state:", error);
        }
      }
      setIsInitialized(true);
    };

    initialize();
  }, []); // Empty dependency array - runs only once

  // Save state changes
  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem("currentView", currentView);
    }
  }, [currentView, isInitialized]);

  useEffect(() => {
    if (isInitialized) {
      localStorage.setItem("viewState", JSON.stringify(viewState));
    }
  }, [viewState, isInitialized]);

  const handleLogin = (user: any) => {
    login(user);
    const newView = user.role === "admin" ? "dashboard" : "home";
    const newViewState: ViewState = {
      type: user.role === "admin" ? "admin" : "home",
    };

    setCurrentView(newView);
    setViewState(newViewState);
  };

  const handleLogout = () => {
    logout();
    setCurrentView("home");
    setViewState({ type: "home" });
  };

  // FIX: Navigation function - remove any resetting logic
  const handleViewChange = (view: string) => {
    console.log("Changing view to:", view); // Debug log

    let newViewState: ViewState;

    switch (view) {
      case "home":
        newViewState = { type: "home" };
        break;
      case "search":
        newViewState = { type: "search" };
        break;
      case "library":
        newViewState = { type: "library" };
        break;
      case "favorites":
        newViewState = { type: "favorites" };
        break;
      case "profile":
        newViewState = { type: "profile" };
        break;
      case "dashboard":
      case "manage-stories":
      case "add-story":
      case "drafts":
      case "categories":
      case "settings":
        newViewState = { type: "admin" };
        break;
      default:
        newViewState = { type: "home" };
    }

    setCurrentView(view);
    setViewState(newViewState);
    setSidebarOpen(false);
  };

  const handleStorySelect = (storyId: string) => {
    setViewState({ type: "story-details", data: { storyId } });
  };

  const handleStartReading = (storyId: string, chapterId: string) => {
    setViewState({ type: "chapter-reader", data: { storyId, chapterId } });
  };

  const handleBackToStories = () => {
    setViewState({ type: "home" });
    setCurrentView("home");
  };

  const handleBackToStoryDetails = () => {
    if (viewState.data?.storyId) {
      setViewState({
        type: "story-details",
        data: { storyId: viewState.data.storyId },
      });
    }
  };

  // Show loading until initialized
  if (!isInitialized) {
    return (
      <div className="flex items-center justify-center h-screen bg-[var(--bg-primary)]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[var(--primary)]"></div>
      </div>
    );
  }

  // Show login form if user is not logged in
  if (!state.user) {
    if (showSignup) {
      return (
        <SignupForm
          onSignupSuccess={() => setShowSignup(false)}
          onNavigateToLogin={() => setShowSignup(false)}
        />
      );
    }
    return (
      <LoginForm
        onLogin={handleLogin}
        onNavigateToSignup={() => setShowSignup(true)}
      />
    );
  }

  // Render chapter reader in full screen
  if (
    viewState.type === "chapter-reader" &&
    viewState.data?.storyId &&
    viewState.data?.chapterId
  ) {
    return (
      // In the ChapterReader section of App.tsx, update the component call:
      <ChapterReader
        storyId={viewState.data.storyId}
        chapterId={viewState.data.chapterId}
        onBack={handleBackToStoryDetails}
        onChapterChange={(newChapterId: string) => {
          // Create new view state for the new chapter
          const newViewState: ViewState = {
            type: "chapter-reader",
            data: {
              storyId: viewState.data!.storyId!,
              chapterId: newChapterId,
            },
          };
          setViewState(newViewState);
        }}
      />
    );
  }

  return (
    <div className="flex h-screen bg-[var(--bg-primary)]">
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <Sidebar
        currentView={currentView}
        onViewChange={handleViewChange}
        onLogout={handleLogout}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="flex-1 flex flex-col overflow-hidden">
        <div className="lg:hidden bg-[var(--bg-secondary)] border-b border-[var(--border-color)] p-4 flex items-center justify-between">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 text-[var(--neutral-600)] hover:text-[var(--primary)]"
          >
            <svg
              className="w-6 h-6"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
          <h1 className="font-bold text-lg text-[var(--primary)] font-['Playfair_Display']">
            StoryVerse
          </h1>
          <div className="w-10" />
        </div>

        {/* User Views */}
        {!isAdmin && (
          <>
            {viewState.type === "home" && (
              <HomePage onStorySelect={handleStorySelect} />
            )}
            {viewState.type === "story-details" && viewState.data?.storyId && (
              <StoryDetails
                storyId={viewState.data.storyId}
                onBack={handleBackToStories}
                onStartReading={(chapterId: string) =>
                  handleStartReading(viewState.data!.storyId!, chapterId)
                }
              />
            )}
            {viewState.type === "search" && (
              <SearchPage onStorySelect={handleStorySelect} />
            )}
            {viewState.type === "library" && (
              <LibraryPage onStorySelect={handleStorySelect} />
            )}
            {viewState.type === "favorites" && (
              <FavoritesPage onStorySelect={handleStorySelect} />
            )}
            {viewState.type === "profile" && <ProfilePage />}
            {currentView === "settings" && <SettingsPage />}
          </>
        )}

        {/* Admin Views */}
        {isAdmin && (
          <>
            {currentView === "dashboard" && (
              <Dashboard onNavigate={handleViewChange} />
            )}
            {(currentView === "manage-stories" ||
              currentView === "add-story" ||
              currentView === "drafts") && (
              <StoryManager currentView={currentView} />
            )}
            {currentView === "categories" && (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center">
                  <h2 className="text-2xl font-semibold mb-4">
                    Categories Management
                  </h2>
                  <p>Coming soon</p>
                </div>
              </div>
            )}
            {currentView === "settings" && <SettingsPage />}
          </>
        )}
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </ThemeProvider>
  );
}

export default App;
