export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  created_at: string;
}

export interface Story {
  id: string;
  title: string;
  description: string;
  cover_url?: string;
  author?: string;
  category_id?: string;
  status: 'draft' | 'published';
  created_at: string;
  updated_at: string;
  chapters?: Chapter[];
}

export interface Chapter {
  id: string;
  story_id: string;
  title: string;
  content: string;
  chapter_number: number;
  created_at: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
}

export interface ReadingProgress {
  id: string;
  user_id: string;
  story_id: string;
  chapter_id: string;
  progress_percent: number;
  last_read: string;
}

export interface Favorite {
  id: string;
  user_id: string;
  story_id: string;
  created_at: string;
}

export interface AppState {
  user: User | null;
  stories: Story[];
  categories: Category[];
  readingProgress: ReadingProgress[];
  favorites: Favorite[];
}