const jwt = require('jsonwebtoken');
const User = require('../models/User');

exports.protect = async (req, res, next) => {
  try {
    console.log("🔐 Auth middleware checking request...");
    
    // 1) Get token from header
    let token;
    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
      console.log("🔑 Token found in header");
    } else {
      console.log("❌ No token in header");
    }

    if (!token) {
      console.log("❌ No token provided");
      return res.status(401).json({
        status: 'error',
        message: 'You are not logged in. Please log in to get access.'
      });
    }

    // 2) Verify token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key');
      console.log("✅ Token verified, user ID:", decoded.id);
    } catch (jwtError) {
      console.log("❌ Token verification failed:", jwtError.message);
      return res.status(401).json({
        status: 'error',
        message: 'Invalid token. Please log in again.'
      });
    }

    // 3) Check if user still exists
    const currentUser = await User.findById(decoded.id);
    if (!currentUser) {
      console.log("❌ User not found for token");
      return res.status(401).json({
        status: 'error',
        message: 'The user belonging to this token no longer exists.'
      });
    }

    console.log("✅ User found:", currentUser.email);

    // 4) Grant access to protected route
    req.user = currentUser;
    next();
  } catch (error) {
    console.error("❌ Auth middleware error:", error);
    return res.status(500).json({
      status: 'error',
      message: 'Authentication error'
    });
  }
};