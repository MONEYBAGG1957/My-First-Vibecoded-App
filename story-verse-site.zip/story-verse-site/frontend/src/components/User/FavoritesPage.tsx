import React, { useState, useMemo } from "react";
import { Heart, Search, Filter, X } from "lucide-react";
import { useApp } from "../../context/AppContext";
import StoryCard from "./StoryCard";

interface FavoritesPageProps {
  onStorySelect: (storyId: string) => void;
}

const FavoritesPage: React.FC<FavoritesPageProps> = ({ onStorySelect }) => {
  const { state } = useApp();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState<"recent" | "title" | "author">("recent");

  // Get favorite stories with details
  const favoriteStories = useMemo(() => {
    const favorites = state.favorites
      .map((favorite) => {
        const story = state.stories.find(
          (s) => s.id === favorite.story_id && s.status === "published"
        );
        return story ? { story, favorite } : null;
      })
      .filter(Boolean);

    // Filter by search term
    const filtered = favorites.filter((item) => {
      if (!searchTerm) return true;
      const story = item!.story;
      return (
        story.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        story.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (story.author &&
          story.author.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    });

    // Sort favorites
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "recent":
          return (
            new Date(b!.favorite.created_at).getTime() -
            new Date(a!.favorite.created_at).getTime()
          );
        case "title":
          return a!.story.title.localeCompare(b!.story.title);
        case "author":
          return (a!.story.author || "").localeCompare(b!.story.author || "");
        default:
          return 0;
      }
    });

    return filtered;
  }, [state.favorites, state.stories, searchTerm, sortBy]);

  const clearSearch = () => {
    setSearchTerm("");
  };

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <div className="flex items-center gap-3 mb-4">
            <div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display']">
                My Favorites
              </h1>
              <p className="text-base sm:text-lg text-[var(--neutral-600)]">
                {favoriteStories.length} favorite{" "}
                {favoriteStories.length === 1 ? "story" : "stories"}
              </p>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-4 sm:p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] w-5 h-5" />
                <input
                  type="text"
                  placeholder="Search your favorites..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="input-field pl-10 pr-10"
                />
                {searchTerm && (
                  <button
                    onClick={clearSearch}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[var(--neutral-400)] hover:text-[var(--neutral-600)]"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Sort */}
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-[var(--neutral-500)]" />
              <select
                value={sortBy}
                onChange={(e) =>
                  setSortBy(e.target.value as "recent" | "title" | "author")
                }
                className="input-field min-w-[150px]"
              >
                <option value="recent">Recently Added</option>
                <option value="title">Title (A-Z)</option>
                <option value="author">Author (A-Z)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Favorites Grid */}
        {favoriteStories.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {favoriteStories.map((item) => (
              <div key={item!.story.id} className="relative">
                <StoryCard
                  story={item!.story}
                  onClick={() => onStorySelect(item!.story.id)}
                />
                <div className="absolute top-2 left-2 bg-[var(--error)] text-white px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                  <Heart className="w-3 h-3 fill-current" />
                  <span className="hidden sm:inline">Favorite</span>
                </div>
                <div className="absolute bottom-2 right-2 bg-black/60 text-white px-2 py-1 rounded text-xs">
                  Added{" "}
                  {new Date(item!.favorite.created_at).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Heart className="w-16 h-16 text-[var(--neutral-300)] mx-auto mb-4" />
            <h3 className="text-xl font-medium text-[var(--neutral-600)] mb-2">
              {searchTerm ? "No matching favorites" : "No favorite stories yet"}
            </h3>
            <p className="text-[var(--neutral-500)] mb-4">
              {searchTerm
                ? `No favorites match "${searchTerm}"`
                : "Start adding stories to your favorites to see them here"}
            </p>
            {searchTerm && (
              <button onClick={clearSearch} className="btn-primary">
                Clear Search
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default FavoritesPage;
