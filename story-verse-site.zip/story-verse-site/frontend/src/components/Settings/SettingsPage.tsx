import React from "react";
import { Moon, Sun, Palette, User, Bell, Shield } from "lucide-react";
import { useTheme } from "../../context/ThemeContext";
import { useApp } from "../../context/AppContext";

const SettingsPage: React.FC = () => {
  const { theme, toggleTheme } = useTheme();
  const { state } = useApp();

  const settingsSections = [
    {
      title: "Appearance",
      icon: Palette,
      items: [
        {
          id: "theme",
          label: "Dark Mode",
          description: "Switch between light and dark themes",
          component: (
            <button
              onClick={toggleTheme}
              className="flex items-center gap-3 p-3 rounded-lg border border-[var(--neutral-200)] hover:bg-[var(--neutral-50)] transition-colors duration-200"
            >
              {theme === "dark" ? (
                <Sun className="w-5 h-5 text-[var(--secondary)]" />
              ) : (
                <Moon className="w-5 h-5 text-[var(--neutral-600)]" />
              )}
              <div className="flex-1 text-left">
                <p className="font-medium text-[var(--neutral-800)]">
                  {theme === "dark" ? "Light Mode" : "Dark Mode"}
                </p>
                <p className="text-sm text-[var(--neutral-500)]">
                  {theme === "dark"
                    ? "Switch to light theme"
                    : "Switch to dark theme"}
                </p>
              </div>
              <div
                className={`w-12 h-6 rounded-full transition-colors duration-200 ${
                  theme === "dark"
                    ? "bg-[var(--primary)]"
                    : "bg-[var(--neutral-300)]"
                }`}
              >
                <div
                  className={`w-5 h-5 rounded-full shadow-md transform transition-transform duration-200 ${
                    theme === "dark"
                      ? "bg-white translate-x-6"
                      : "bg-[var(--primary)] translate-x-0.5"
                  } mt-0.5`}
                />
              </div>
            </button>
          ),
        },
      ],
    },
    {
      title: "Account",
      icon: User,
      items: [
        {
          id: "profile",
          label: "Profile Settings",
          description: "Manage your profile information",
          component: (
            <div className="p-3 rounded-lg border border-[var(--neutral-200)] bg-[var(--neutral-50)]">
              <p className="text-sm text-[var(--neutral-500)]">
                Profile settings coming soon
              </p>
            </div>
          ),
        },
      ],
    },
    {
      title: "Notifications",
      icon: Bell,
      items: [
        {
          id: "notifications",
          label: "Notification Preferences",
          description: "Configure how you receive notifications",
          component: (
            <div className="p-3 rounded-lg border border-[var(--neutral-200)] bg-[var(--neutral-50)]">
              <p className="text-sm text-[var(--neutral-500)]">
                Notification settings coming soon
              </p>
            </div>
          ),
        },
      ],
    },
    {
      title: "Privacy & Security",
      icon: Shield,
      items: [
        {
          id: "privacy",
          label: "Privacy Settings",
          description: "Control your privacy and data settings",
          component: (
            <div className="p-3 rounded-lg border border-[var(--neutral-200)] bg-[var(--neutral-50)]">
              <p className="text-sm text-[var(--neutral-500)]">
                Privacy settings coming soon
              </p>
            </div>
          ),
        },
      ],
    },
  ];

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      <div className="p-4 sm:p-6 lg:p-8">
        {/* Header */}
        <div className="mb-6 sm:mb-8">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-2">
            Settings
          </h1>
          <p className="text-base sm:text-lg text-[var(--neutral-600)]">
            Customize your reading experience and account preferences
          </p>
        </div>

        {/* User Info */}
        {state.user && (
          <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-6 mb-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-[var(--secondary)] rounded-full flex items-center justify-center">
                <User className="w-8 h-8 text-[var(--primary)]" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-[var(--neutral-800)]">
                  {state.user.name}
                </h3>
                <p className="text-[var(--neutral-600)]">{state.user.email}</p>
                <span className="inline-block px-3 py-1 bg-[var(--primary)] text-white text-sm rounded-full mt-2 capitalize">
                  {state.user.role}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Settings Sections */}
        <div className="space-y-8">
          {settingsSections.map((section) => {
            const Icon = section.icon;
            return (
              <div
                key={section.title}
                className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)]"
              >
                <div className="p-6 border-b border-[var(--neutral-200)]">
                  <div className="flex items-center gap-3">
                    <Icon className="w-6 h-6 text-[var(--primary)]" />
                    <h2 className="text-xl font-semibold text-[var(--neutral-800)] font-['Playfair_Display']">
                      {section.title}
                    </h2>
                  </div>
                </div>
                <div className="p-6 space-y-4">
                  {section.items.map((item) => (
                    <div key={item.id}>
                      <div className="mb-2">
                        <h3 className="font-medium text-[var(--neutral-800)]">
                          {item.label}
                        </h3>
                        <p className="text-sm text-[var(--neutral-500)]">
                          {item.description}
                        </p>
                      </div>
                      {item.component}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Theme Preview */}
        <div className="mt-8 bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)] p-6">
          <h3 className="text-lg font-semibold text-[var(--neutral-800)] mb-4">
            Theme Preview
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg border border-[var(--neutral-200)] bg-[var(--neutral-50)]">
              <h4 className="font-medium text-[var(--neutral-800)] mb-2">
                Current Theme
              </h4>
              <div className="space-y-2">
                <div className="h-3 bg-[var(--primary)] rounded"></div>
                <div className="h-3 bg-[var(--secondary)] rounded"></div>
                <div className="h-3 bg-[var(--tertiary)] rounded"></div>
                <div className="h-3 bg-[var(--quaternary)] rounded"></div>
              </div>
              <p className="text-sm text-[var(--neutral-600)] mt-2 capitalize">
                {theme} Mode
              </p>
            </div>
            <div className="p-4 rounded-lg border border-[var(--neutral-200)] bg-[var(--neutral-50)]">
              <h4 className="font-medium text-[var(--neutral-800)] mb-2">
                Color Palette
              </h4>
              <div className="grid grid-cols-4 gap-2">
                <div
                  className="h-8 bg-[var(--primary)] rounded"
                  title="Primary"
                ></div>
                <div
                  className="h-8 bg-[var(--secondary)] rounded"
                  title="Secondary"
                ></div>
                <div
                  className="h-8 bg-[var(--tertiary)] rounded"
                  title="Tertiary"
                ></div>
                <div
                  className="h-8 bg-[var(--quaternary)] rounded"
                  title="Quaternary"
                ></div>
              </div>
              <p className="text-sm text-[var(--neutral-600)] mt-2">
                StoryVerse Colors
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
