import React, { useState, useEffect } from "react";
import {
  ArrowLeft,
  Play,
  Heart,
  Share2,
  Clock,
  User,
  Loader,
} from "lucide-react";
import { useApp } from "../../context/AppContext";
import { Chapter } from "../../types";

interface StoryDetailsProps {
  storyId: string;
  onBack: () => void;
  onStartReading: (chapterId: string) => void;
}

const StoryDetails: React.FC<StoryDetailsProps> = ({
  storyId,
  onBack,
  onStartReading,
}) => {
  const { state, toggleFavorite } = useApp();
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const story = state.stories.find((s) => s.id === storyId);
  const isFavorite = state.favorites.some((f) => f.story_id === storyId);
  const progress = state.readingProgress.find((p) => p.story_id === storyId);

  // Fetch chapters from backend
  useEffect(() => {
    const fetchChapters = async () => {
      if (!storyId) return;

      try {
        setLoading(true);
        setError(null);

        const token = localStorage.getItem("token");
        const headers: HeadersInit = {
          "Content-Type": "application/json",
        };

        if (token) {
          headers.Authorization = `Bearer ${token}`;
        }

        const response = await fetch(
          `http://localhost:5000/api/stories/${storyId}/chapters`,
          { headers }
        );

        if (!response.ok) {
          throw new Error("Failed to fetch chapters");
        }

        const data = await response.json();

        if (data.status === "success") {
          // Transform backend data to match frontend Chapter interface
          const fetchedChapters: Chapter[] = data.data.chapters.map(
            (chapter: any) => ({
              id: chapter._id || chapter.id,
              story_id: chapter.story_id || storyId,
              title: chapter.title,
              content: chapter.content || "", // Content might be empty in list view
              chapter_number: chapter.chapter_number,
              created_at: chapter.createdAt || chapter.created_at,
            })
          );

          setChapters(fetchedChapters);
        } else {
          throw new Error(data.message || "Failed to load chapters");
        }
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Failed to load chapters"
        );
        console.error("Error fetching chapters:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchChapters();
  }, [storyId]);

  if (!story) {
    return (
      <div className="flex-1 bg-[var(--neutral-50)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold text-[var(--neutral-600)] mb-4">
            Story not found
          </h2>
          <button onClick={onBack} className="btn-primary">
            Go Back
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 bg-[var(--neutral-50)] overflow-y-auto">
      {/* Header */}
      <div className="bg-dark border-b border-[var(--neutral-200)] p-4 sm:p-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-[var(--neutral-600)] hover:text-[var(--primary)] transition-colors duration-200 mb-4"
        >
          <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
          <span className="text-sm sm:text-base">Back to Stories</span>
        </button>
      </div>

      {/* Story Banner */}
      <div className="relative">
        <div className="h-60 sm:h-80 bg-gradient-to-r from-[var(--primary)]/90 to-[var(--tertiary)]/90 relative overflow-hidden">
          {story.cover_url && (
            <img
              src={story.cover_url}
              alt={story.title}
              className="absolute inset-0 w-full h-full object-cover mix-blend-overlay"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />

          <div className="relative z-10 container mx-auto px-4 sm:px-8 h-full flex items-end pb-6 sm:pb-8">
            <div className="text-white">
              <h1 className="text-2xl sm:text-3xl lg:text-5xl font-bold font-['Playfair_Display'] mb-3 sm:mb-4">
                {story.title}
              </h1>

              {story.author && (
                <div className="flex items-center gap-2 text-white/90 mb-3 sm:mb-4">
                  <User className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="text-base sm:text-lg editorial-text">
                    by {story.author}
                  </span>
                </div>
              )}

              <p className="text-sm sm:text-base lg:text-xl text-white/90 max-w-2xl leading-relaxed">
                {story.description}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-8 py-6 sm:py-8">
        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mb-6 sm:mb-8">
          <button
            onClick={() =>
              chapters.length > 0 && onStartReading(chapters[0].id)
            }
            disabled={chapters.length === 0 || loading}
            className="btn-primary flex items-center justify-center gap-2 sm:gap-3 text-sm sm:text-base disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-4 h-4 sm:w-5 sm:h-5" />
            {progress ? "Continue Reading" : "Start Reading"}
            {loading && <Loader className="w-4 h-4 animate-spin" />}
          </button>

          <button
            onClick={() => toggleFavorite(story.id)}
            className={`btn-tertiary flex items-center justify-center gap-2 sm:gap-3 text-sm sm:text-base ${
              isFavorite
                ? "bg-[var(--error)] text-white border-[var(--error)] hover:bg-[var(--error)]/90"
                : ""
            }`}
          >
            <Heart
              className={`w-4 h-4 sm:w-5 sm:h-5 ${
                isFavorite ? "fill-current" : ""
              }`}
            />
            <span className="hidden sm:inline">
              {isFavorite ? "Remove from Favorites" : "Add to Favorites"}
            </span>
            <span className="sm:hidden">{isFavorite ? "Remove" : "Add"}</span>
          </button>

          <button className="btn-tertiary flex items-center justify-center gap-2 sm:gap-3 text-sm sm:text-base">
            <Share2 className="w-4 h-4 sm:w-5 sm:h-5" />
            Share
          </button>
        </div>

        {/* Progress */}
        {progress && (
          <div className="bg-dark rounded-xl p-4 sm:p-6 shadow-sm border border-[var(--neutral-200)] mb-6 sm:mb-8">
            <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
              <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-[var(--primary)]" />
              <h3 className="font-semibold text-[var(--neutral-800)] text-sm sm:text-base">
                Reading Progress
              </h3>
            </div>
            <div className="flex items-center gap-3 sm:gap-4">
              <div className="flex-1">
                <div className="w-full bg-[var(--neutral-200)] rounded-full h-2 sm:h-3">
                  <div
                    className="progress-bar h-2 sm:h-3 rounded-full transition-all duration-300"
                    style={{ width: `${progress.progress_percent}%` }}
                  ></div>
                </div>
              </div>
              <span className="text-xs sm:text-sm font-medium text-[var(--neutral-600)]">
                {Math.round(progress.progress_percent)}% complete
              </span>
            </div>
          </div>
        )}

        {/* Chapters Section */}
        <div className="bg-dark rounded-xl shadow-sm border border-[var(--neutral-200)]">
          <div className="p-4 sm:p-6 border-b border-[var(--neutral-200)]">
            <div className="flex items-center justify-between">
              <h3 className="text-xl sm:text-2xl font-semibold text-[var(--neutral-800)] font-['Playfair_Display']">
                Chapters
              </h3>
              {chapters.length > 0 && (
                <span className="text-sm text-[var(--neutral-600)]">
                  {chapters.length} chapter{chapters.length !== 1 ? "s" : ""}
                </span>
              )}
            </div>
          </div>

          {/* Loading State */}
          {loading && (
            <div className="p-8 text-center">
              <Loader className="w-6 h-6 animate-spin mx-auto mb-2 text-[var(--primary)]" />
              <p className="text-[var(--neutral-600)]">Loading chapters...</p>
            </div>
          )}

          {/* Error State */}
          {error && !loading && (
            <div className="p-8 text-center">
              <p className="text-red-600 mb-4">
                Error loading chapters: {error}
              </p>
              <button
                onClick={() => window.location.reload()}
                className="btn-primary text-sm"
              >
                Try Again
              </button>
            </div>
          )}

          {/* Empty State */}
          {!loading && !error && chapters.length === 0 && (
            <div className="p-8 text-center">
              <p className="text-[var(--neutral-600)] mb-2">
                No chapters available yet.
              </p>
              <p className="text-sm text-[var(--neutral-500)]">
                Check back later for new chapters!
              </p>
            </div>
          )}

          {/* Chapters List */}
          {!loading && !error && chapters.length > 0 && (
            <div className="divide-y divide-[var(--neutral-200)]">
              {chapters.map((chapter) => (
                <button
                  key={chapter.id}
                  onClick={() => onStartReading(chapter.id)}
                  className="w-full p-4 sm:p-6 text-left hover:bg-[var(--neutral-50)] transition-colors duration-200 group"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <h4 className="font-medium text-[var(--neutral-800)] group-hover:text-[var(--primary)] transition-colors duration-200 text-sm sm:text-base truncate">
                        Chapter {chapter.chapter_number}: {chapter.title}
                      </h4>
                      <p className="text-xs sm:text-sm text-[var(--neutral-600)] mt-1 truncate">
                        Added{" "}
                        {new Date(chapter.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <Play className="w-4 h-4 sm:w-5 sm:h-5 text-[var(--neutral-400)] group-hover:text-[var(--primary)] transition-colors duration-200 flex-shrink-0 ml-2" />
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StoryDetails;
