import React, { useState } from "react";
import {
  BookOpen,
  Play,
  Star,
  Users,
  TrendingUp,
  ArrowRight,
  Eye,
  Heart,
} from "lucide-react";

interface LandingPageProps {
  onNavigateToLogin: () => void;
  onNavigateToSignup: () => void;
}

// Mock featured stories for the landing page
const featuredStories = [
  {
    id: "1",
    title: "The Enchanted Forest",
    description:
      "A magical journey through an ancient forest where every tree holds a secret and every path leads to adventure.",
    cover_url:
      "https://images.pexels.com/photos/957024/forest-trees-perspective-bright-957024.jpeg?auto=compress&cs=tinysrgb&w=800",
    author: "Elena Moonwhisper",
    rating: 4.8,
    reads: "12.5K",
    preview:
      "The ancient forest stretched endlessly before Elena, its towering trees creating a cathedral of green that filtered the sunlight into dancing patterns...",
  },
  {
    id: "2",
    title: "Digital Nomad Chronicles",
    description:
      "Follow the adventures of a tech professional traveling the world while building the next big startup.",
    cover_url:
      "https://images.pexels.com/photos/1181396/pexels-photo-1181396.jpeg?auto=compress&cs=tinysrgb&w=800",
    author: "Marcus Chen",
    rating: 4.6,
    reads: "8.2K",
    preview:
      "The notification sound pierced through the morning silence of the Bali café. Another investor had declined the pitch...",
  },
  {
    id: "3",
    title: "The Last Library",
    description:
      "In a post-apocalyptic world, one librarian guards the last repository of human knowledge against all odds.",
    cover_url:
      "https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=800",
    author: "Sarah Bookwright",
    rating: 4.9,
    reads: "15.7K",
    preview:
      "The dust settled on the empty streets as Maya carefully locked the heavy oak doors behind her. Inside, thousands of books waited in silence...",
  },
  {
    id: "4",
    title: "Midnight Café Mysteries",
    description:
      "Strange things happen after midnight at the little café on Maple Street. Each cup of coffee comes with a story.",
    cover_url:
      "https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=800",
    author: "Isabella Night",
    rating: 4.7,
    reads: "9.8K",
    preview:
      "The clock struck midnight as the last customer left. But as always, the real customers were just beginning to arrive...",
  },
];

const LandingPage: React.FC<LandingPageProps> = ({
  onNavigateToLogin,
  onNavigateToSignup,
}) => {
  const [selectedStory, setSelectedStory] = useState(featuredStories[0]);
  const [showPreview, setShowPreview] = useState(false);

  const handleStorySelect = (story: (typeof featuredStories)[0]) => {
    setSelectedStory(story);
  };

  const handleReadPreview = (story: (typeof featuredStories)[0]) => {
    setSelectedStory(story);
    setShowPreview(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[var(--neutral-50)] to-[var(--neutral-100)]">
      {/* Navigation Header */}
      <nav className="bg-white/90 backdrop-blur-sm border-b border-[var(--neutral-200)] sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-[var(--primary)] rounded-lg flex items-center justify-center">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <h1 className="font-bold text-2xl text-[var(--primary)] font-['Playfair_Display']">
                StoryVerse
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={onNavigateToLogin}
                className="text-[var(--neutral-700)] hover:text-[var(--primary)] font-medium transition-colors duration-200"
              >
                Sign In
              </button>
              <button onClick={onNavigateToSignup} className="btn-primary">
                Get Started
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-6">
                Discover Amazing
                <span className="text-[var(--primary)]"> Stories</span>
              </h1>
              <p className="text-xl text-[var(--neutral-600)] mb-8 leading-relaxed">
                Immerse yourself in worlds of imagination. Read captivating
                stories, share your own tales, and connect with a community of
                storytellers.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <button
                  onClick={onNavigateToSignup}
                  className="btn-primary flex items-center justify-center gap-3 text-lg px-8 py-4"
                >
                  <Play className="w-5 h-5" />
                  Start Reading
                </button>
                <button
                  onClick={() =>
                    document
                      .getElementById("featured")
                      ?.scrollIntoView({ behavior: "smooth" })
                  }
                  className="btn-tertiary flex items-center justify-center gap-3 text-lg px-8 py-4"
                >
                  <Eye className="w-5 h-5" />
                  Browse Stories
                </button>
              </div>
            </div>
            <div className="relative">
              <div className="relative z-10">
                <img
                  src={selectedStory.cover_url}
                  alt={selectedStory.title}
                  className="w-full max-w-md mx-auto rounded-2xl shadow-2xl"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-2xl" />
                <div className="absolute bottom-6 left-6 right-6 text-white">
                  <h3 className="text-2xl font-bold font-['Playfair_Display'] mb-2">
                    {selectedStory.title}
                  </h3>
                  <p className="text-white/90 mb-3">
                    by {selectedStory.author}
                  </p>
                  <div className="flex items-center gap-4 text-sm">
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-current text-yellow-400" />
                      <span>{selectedStory.rating}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Eye className="w-4 h-4" />
                      <span>{selectedStory.reads} reads</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 w-72 h-72 bg-[var(--secondary)]/20 rounded-full blur-3xl" />
              <div className="absolute -bottom-4 -left-4 w-72 h-72 bg-[var(--primary)]/20 rounded-full blur-3xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-[var(--primary)]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="w-8 h-8 text-[var(--primary)]" />
              </div>
              <h3 className="text-3xl font-bold text-[var(--neutral-800)] mb-2">
                10,000+
              </h3>
              <p className="text-[var(--neutral-600)]">Stories Published</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[var(--secondary)]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-[var(--secondary)]" />
              </div>
              <h3 className="text-3xl font-bold text-[var(--neutral-800)] mb-2">
                50,000+
              </h3>
              <p className="text-[var(--neutral-600)]">Active Readers</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-[var(--tertiary)]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-[var(--tertiary)]" />
              </div>
              <h3 className="text-3xl font-bold text-[var(--neutral-800)] mb-2">
                1M+
              </h3>
              <p className="text-[var(--neutral-600)]">Stories Read</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Stories Section */}
      <section id="featured" className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-[var(--neutral-800)] font-['Playfair_Display'] mb-4">
              Featured Stories
            </h2>
            <p className="text-xl text-[var(--neutral-600)] max-w-2xl mx-auto">
              Discover captivating tales from our community of talented writers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {featuredStories.map((story) => (
              <div
                key={story.id}
                className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer group"
                onClick={() => handleStorySelect(story)}
              >
                <div className="relative">
                  <img
                    src={story.cover_url}
                    alt={story.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-3 right-3 bg-white/90 rounded-full p-2">
                    <Heart className="w-4 h-4 text-[var(--neutral-600)]" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="font-semibold text-lg text-[var(--neutral-800)] mb-2 group-hover:text-[var(--primary)] transition-colors duration-200">
                    {story.title}
                  </h3>
                  <p className="text-sm text-[var(--neutral-500)] mb-3">
                    by {story.author}
                  </p>
                  <p className="text-sm text-[var(--neutral-600)] line-clamp-3 mb-4">
                    {story.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-sm text-[var(--neutral-500)]">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-current text-yellow-400" />
                        <span>{story.rating}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="w-4 h-4" />
                        <span>{story.reads}</span>
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleReadPreview(story);
                      }}
                      className="text-[var(--primary)] hover:text-[var(--primary)]/80 font-medium text-sm"
                    >
                      Preview
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={onNavigateToSignup}
              className="btn-primary flex items-center gap-3 mx-auto text-lg px-8 py-4"
            >
              View All Stories
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </section>

      {/* Story Preview Modal */}
      {showPreview && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="p-6 border-b border-[var(--neutral-200)]">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-[var(--neutral-800)] font-['Playfair_Display']">
                    {selectedStory.title}
                  </h3>
                  <p className="text-[var(--neutral-600)]">
                    by {selectedStory.author}
                  </p>
                </div>
                <button
                  onClick={() => setShowPreview(false)}
                  className="p-2 text-[var(--neutral-500)] hover:text-[var(--neutral-700)] transition-colors duration-200"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>
            </div>
            <div className="p-6 overflow-y-auto">
              <p className="text-[var(--neutral-700)] leading-relaxed mb-6">
                {selectedStory.preview}
              </p>
              <div className="bg-[var(--neutral-50)] rounded-lg p-4 text-center">
                <p className="text-[var(--neutral-600)] mb-4">
                  Sign up to read the full story and discover thousands more!
                </p>
                <div className="flex gap-3 justify-center">
                  <button onClick={onNavigateToSignup} className="btn-primary">
                    Sign Up Free
                  </button>
                  <button onClick={onNavigateToLogin} className="btn-tertiary">
                    Sign In
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-[var(--primary)] to-[var(--tertiary)] py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white font-['Playfair_Display'] mb-4">
            Ready to Start Your Story Journey?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join thousands of readers and writers in our vibrant storytelling
            community
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={onNavigateToSignup}
              className="bg-white text-[var(--primary)] px-8 py-4 rounded-lg font-semibold hover:bg-white/90 transition-colors duration-200 flex items-center justify-center gap-3"
            >
              <BookOpen className="w-5 h-5" />
              Start Reading Free
            </button>
            <button
              onClick={onNavigateToLogin}
              className="border-2 border-white text-white px-8 py-4 rounded-lg font-semibold hover:bg-white hover:text-[var(--primary)] transition-all duration-200"
            >
              Sign In
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-[var(--neutral-800)] text-white py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-[var(--primary)] rounded-lg flex items-center justify-center">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                <h3 className="font-bold text-xl font-['Playfair_Display']">
                  StoryVerse
                </h3>
              </div>
              <p className="text-[var(--neutral-400)]">
                Where stories come alive and imagination knows no bounds.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Discover</h4>
              <ul className="space-y-2 text-[var(--neutral-400)]">
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Featured Stories
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    New Releases
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Popular Authors
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Categories
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Community</h4>
              <ul className="space-y-2 text-[var(--neutral-400)]">
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Write Stories
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Join Discussions
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Author Guidelines
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Help Center
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-[var(--neutral-400)]">
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Privacy Policy
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Terms of Service
                  </a>
                </li>
                <li>
                  <a
                    href="#"
                    className="hover:text-white transition-colors duration-200"
                  >
                    Contact
                  </a>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-[var(--neutral-700)] mt-8 pt-8 text-center text-[var(--neutral-400)]">
            <p>&copy; 2024 StoryVerse. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default LandingPage;
